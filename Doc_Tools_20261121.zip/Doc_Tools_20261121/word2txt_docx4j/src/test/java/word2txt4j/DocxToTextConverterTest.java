package word2txt4j;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.wml.P;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Tr;
import org.junit.jupiter.api.Test;

/** DocxToTextConverter 测试：表格规则与段落规范化（与 POI 版同用例）。 */
class DocxToTextConverterTest {

    @Test
    void 基础表格一行一自然段竖线分隔() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 2, 2);
        DocxFixture.setCell(t, 0, 0, "a");
        DocxFixture.setCell(t, 0, 1, "b");
        DocxFixture.setCell(t, 1, 0, "c");
        DocxFixture.setCell(t, 1, 1, "d");

        assertEquals(List.of("a|b", "c|d"), DocxFixture.toLines(doc));
    }

    @Test
    void 行首空单元格保留前导竖线() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 1, 2);
        DocxFixture.setCell(t, 0, 0, "");
        DocxFixture.setCell(t, 0, 1, "值");

        assertEquals(List.of("|值"), DocxFixture.toLines(doc));
    }

    @Test
    void 横向合并展开为空列保持对齐() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 2, 3);
        DocxFixture.setCell(t, 0, 0, "名称");
        DocxFixture.setCell(t, 0, 1, "说明");
        DocxFixture.setCell(t, 0, 2, "备注");
        DocxFixture.setCell(t, 1, 0, "x");
        DocxFixture.setCell(t, 1, 2, "z");
        DocxFixture.mergeCells(t, 1, 0, 2);

        assertEquals(List.of("名称|说明|备注", "x||z"), DocxFixture.toLines(doc));
    }

    @Test
    void 单元格内多段合并为一行() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 1, 2);
        DocxFixture.setCell(t, 0, 0, "第一段");
        DocxFixture.appendCellParagraph(t, 0, 0, "第二段");
        DocxFixture.setCell(t, 0, 1, "b");

        assertEquals(List.of("第一段 第二段|b"), DocxFixture.toLines(doc));
    }

    @Test
    void 空段落跳过() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        DocxFixture.plainPara(doc, "第一行");
        doc.getMainDocumentPart().getJaxbElement().getBody().getContent().add(new P());
        DocxFixture.plainPara(doc, "   ");
        DocxFixture.plainPara(doc, "第二行");

        assertEquals(List.of("第一行", "第二行"), DocxFixture.toLines(doc));
    }

    @Test
    void 嵌套表格平铺进单元格() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 1, 2);
        DocxFixture.setCell(t, 0, 0, "外层");
        // 在 (0,1) 单元格内构造嵌套 1x2 表格
        Tc cell = (Tc) ((Tr) t.getContent().get(0)).getContent().get(1);
        Tbl nested = new Tbl();
        Tr ntr = new Tr();
        for (String v : new String[]{"n1", "n2"}) {
            Tc ntc = new Tc();
            ntc.getContent().add(DocxFixture.textParagraph(v));
            ntr.getContent().add(ntc);
        }
        nested.getContent().add(ntr);
        cell.getContent().add(nested);

        assertEquals(List.of("外层|n1|n2"), DocxFixture.toLines(doc));
    }

    @Test
    void 全空表格行跳过() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        Tbl t = DocxFixture.addTable(doc, 2, 2);
        DocxFixture.setCell(t, 0, 0, "a");
        DocxFixture.setCell(t, 0, 1, "b");
        // 第 2 行全部为空
        DocxFixture.setCell(t, 1, 0, "");
        DocxFixture.setCell(t, 1, 1, "");

        assertEquals(List.of("a|b"), DocxFixture.toLines(doc));
    }
}
