package word2txt4j;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static word2txt4j.DocxFixture.LvlSpec;

import java.math.BigInteger;
import java.util.List;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.junit.jupiter.api.Test;

/** NumberingEngine 单元测试：编号还原状态机的核心规则（与 POI 版同用例）。 */
class NumberingEngineTest {

    @Test
    void 多级编号递增与层级重置() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc,
                LvlSpec.of("decimal", "%1"),
                LvlSpec.of("decimal", "%1.%2"),
                LvlSpec.of("decimal", "%1.%2.%3"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "甲");
        DocxFixture.numberedPara(doc, num, 1, "乙");
        DocxFixture.numberedPara(doc, num, 2, "丙");
        DocxFixture.numberedPara(doc, num, 0, "丁");
        DocxFixture.numberedPara(doc, num, 1, "戊");
        DocxFixture.numberedPara(doc, num, 2, "己");
        DocxFixture.numberedPara(doc, num, 1, "庚");

        assertEquals(List.of(
                "1 甲", "1.1 乙", "1.1.1 丙",
                "2 丁", "2.1 戊", "2.1.1 己", "2.2 庚"),
                DocxFixture.toLines(doc));
    }

    @Test
    void 中文章节编号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc,
                LvlSpec.of("chineseCountingThousand", "第%1章"),
                LvlSpec.of("chineseCountingThousand", "第%1章第%2节"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "绪论");
        DocxFixture.numberedPara(doc, num, 1, "研究内容");
        DocxFixture.numberedPara(doc, num, 0, "总结");

        assertEquals(List.of("第一章 绪论", "第一章第一节 研究内容", "第二章 总结"),
                DocxFixture.toLines(doc));
    }

    @Test
    void startOverride首次使用时生效() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc, LvlSpec.of("decimal", "%1"));
        BigInteger num = DocxFixture.addNumWithStartOverride(doc, abs, 0, 5);
        DocxFixture.numberedPara(doc, num, 0, "五");
        DocxFixture.numberedPara(doc, num, 0, "六");

        assertEquals(List.of("5 五", "6 六"), DocxFixture.toLines(doc));
    }

    @Test
    void numId为零表示取消编号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc, LvlSpec.of("decimal", "%1"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "有编号");
        DocxFixture.numberedPara(doc, BigInteger.ZERO, 0, "无编号");

        assertEquals(List.of("1 有编号", "无编号"), DocxFixture.toLines(doc));
    }

    @Test
    void 标题样式链继承编号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc,
                LvlSpec.of("decimal", "%1"),
                LvlSpec.of("decimal", "%1.%2"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.addNumberedStyle(doc, "Heading1", num, 0);
        DocxFixture.addNumberedStyle(doc, "Heading2", num, 1);
        DocxFixture.styledPara(doc, "Heading1", "一级标题");
        DocxFixture.styledPara(doc, "Heading2", "二级标题");
        DocxFixture.styledPara(doc, "Heading1", "又一个一级标题");

        assertEquals(List.of("1 一级标题", "1.1 二级标题", "2 又一个一级标题"),
                DocxFixture.toLines(doc));
    }

    @Test
    void 项目符号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc, LvlSpec.of("bullet", "•"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "列表项一");
        DocxFixture.numberedPara(doc, num, 0, "列表项二");

        assertEquals(List.of("• 列表项一", "• 列表项二"), DocxFixture.toLines(doc));
    }

    @Test
    void numFmt为none时不输出编号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc, LvlSpec.of("none", "%1"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "只有文本");

        assertEquals(List.of("只有文本"), DocxFixture.toLines(doc));
    }

    @Test
    void 孤立深层编号按起始值渲染浅层() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc,
                LvlSpec.of("decimal", "%1"),
                LvlSpec.of("decimal", "%1.%2"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 1, "直接二级");

        assertEquals(List.of("1.1 直接二级"), DocxFixture.toLines(doc));
    }

    @Test
    void lvlRestart限定重置触发级别() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        // 第 3 级设置 lvlRestart=0：仅一级标题出现时重置，二级出现不重置
        BigInteger abs = DocxFixture.addAbstractNum(doc,
                LvlSpec.of("decimal", "%1"),
                LvlSpec.of("decimal", "%1.%2"),
                new LvlSpec("decimal", "%1.%2.%3", 1, 0));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "a");
        DocxFixture.numberedPara(doc, num, 1, "b");
        DocxFixture.numberedPara(doc, num, 2, "c");
        DocxFixture.numberedPara(doc, num, 1, "d");
        DocxFixture.numberedPara(doc, num, 2, "e");
        DocxFixture.numberedPara(doc, num, 0, "f");
        DocxFixture.numberedPara(doc, num, 2, "g");

        assertEquals(List.of(
                "1 a", "1.1 b", "1.1.1 c", "1.2 d", "1.2.2 e", "2 f", "2.1.1 g"),
                DocxFixture.toLines(doc));
    }

    @Test
    void 罗马数字编号() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger abs = DocxFixture.addAbstractNum(doc, LvlSpec.of("upperRoman", "附录%1"));
        BigInteger num = DocxFixture.addNum(doc, abs);
        DocxFixture.numberedPara(doc, num, 0, "参考资料");
        DocxFixture.numberedPara(doc, num, 0, "数据表");

        assertEquals(List.of("附录I 参考资料", "附录II 数据表"), DocxFixture.toLines(doc));
    }

    @Test
    void 手动编号文本不受影响() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        DocxFixture.plainPara(doc, "3.1 手动编号的小节");
        DocxFixture.plainPara(doc, "第X条 手动输入的条款");

        assertEquals(List.of("3.1 手动编号的小节", "第X条 手动输入的条款"),
                DocxFixture.toLines(doc));
    }

    @Test
    void 多个num独立计数() {
        WordprocessingMLPackage doc = DocxFixture.newDoc();
        BigInteger absA = DocxFixture.addAbstractNum(doc, LvlSpec.of("decimal", "%1"));
        BigInteger absB = DocxFixture.addAbstractNum(doc, LvlSpec.of("decimal", "图%1"));
        BigInteger numA = DocxFixture.addNum(doc, absA);
        BigInteger numB = DocxFixture.addNum(doc, absB);
        DocxFixture.numberedPara(doc, numA, 0, "甲一");
        DocxFixture.numberedPara(doc, numB, 0, "图甲");
        DocxFixture.numberedPara(doc, numA, 0, "甲二");
        DocxFixture.numberedPara(doc, numB, 0, "图乙");

        assertEquals(List.of("1 甲一", "图1 图甲", "2 甲二", "图2 图乙"),
                DocxFixture.toLines(doc));
    }
}
