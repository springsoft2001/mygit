package word2txt4j;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.docx4j.jaxb.Context;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.openpackaging.parts.WordprocessingML.NumberingDefinitionsPart;
import org.docx4j.openpackaging.parts.WordprocessingML.StyleDefinitionsPart;
import org.docx4j.wml.Body;
import org.docx4j.wml.Lvl;
import org.docx4j.wml.NumberFormat;
import org.docx4j.wml.Numbering;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.PPr;
import org.docx4j.wml.PPrBase;
import org.docx4j.wml.R;
import org.docx4j.wml.Style;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.TcPr;
import org.docx4j.wml.TcPrInner;
import org.docx4j.wml.Text;
import org.docx4j.wml.Tr;

/**
 * 测试固定装置：用 docx4j 以编程方式构造带编号/样式/表格的内存文档。
 */
final class DocxFixture {

    private static final ObjectFactory F = Context.getWmlObjectFactory();
    private static BigInteger nextAbsId = BigInteger.valueOf(1000);
    private static BigInteger nextNumId = BigInteger.valueOf(1);

    /** 一个编号级别的定义参数 */
    static class LvlSpec {
        final String numFmt;
        final String lvlText;
        final long start;
        final Integer lvlRestart; // null = 不设置

        LvlSpec(String numFmt, String lvlText, long start, Integer lvlRestart) {
            this.numFmt = numFmt;
            this.lvlText = lvlText;
            this.start = start;
            this.lvlRestart = lvlRestart;
        }

        static LvlSpec of(String numFmt, String lvlText) {
            return new LvlSpec(numFmt, lvlText, 1, null);
        }
    }

    private DocxFixture() {
    }

    static WordprocessingMLPackage newDoc() {
        try {
            return WordprocessingMLPackage.createPackage();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /** 添加 abstractNum 定义，返回其 abstractNumId */
    static BigInteger addAbstractNum(WordprocessingMLPackage pkg, LvlSpec... specs) {
        Numbering numbering = numbering(pkg);
        Numbering.AbstractNum abs = F.createNumberingAbstractNum();
        abs.setAbstractNumId(nextAbsId);
        nextAbsId = nextAbsId.add(BigInteger.ONE);
        for (int i = 0; i < specs.length; i++) {
            Lvl lvl = F.createLvl();
            lvl.setIlvl(BigInteger.valueOf(i));
            Lvl.Start st = F.createLvlStart();
            st.setVal(BigInteger.valueOf(specs[i].start));
            lvl.setStart(st);
            org.docx4j.wml.NumFmt nf = F.createNumFmt();
            nf.setVal(NumberFormat.fromValue(specs[i].numFmt));
            lvl.setNumFmt(nf);
            Lvl.LvlText lt = F.createLvlLvlText();
            lt.setVal(specs[i].lvlText);
            lvl.setLvlText(lt);
            if (specs[i].lvlRestart != null) {
                Lvl.LvlRestart lr = F.createLvlLvlRestart();
                lr.setVal(BigInteger.valueOf(specs[i].lvlRestart));
                lvl.setLvlRestart(lr);
            }
            abs.getLvl().add(lvl);
        }
        numbering.getAbstractNum().add(abs);
        return abs.getAbstractNumId();
    }

    /** num -> abstractNum 映射，返回 numId */
    static BigInteger addNum(WordprocessingMLPackage pkg, BigInteger absId) {
        Numbering numbering = numbering(pkg);
        Numbering.Num num = F.createNumberingNum();
        num.setNumId(nextNumId);
        nextNumId = nextNumId.add(BigInteger.ONE);
        Numbering.Num.AbstractNumId aid = F.createNumberingNumAbstractNumId();
        aid.setVal(absId);
        num.setAbstractNumId(aid);
        numbering.getNum().add(num);
        return num.getNumId();
    }

    /** 带 lvlOverride/startOverride 的 num，返回 numId */
    static BigInteger addNumWithStartOverride(WordprocessingMLPackage pkg, BigInteger absId,
                                              int ilvl, long startOverride) {
        Numbering numbering = numbering(pkg);
        Numbering.Num num = F.createNumberingNum();
        num.setNumId(nextNumId);
        nextNumId = nextNumId.add(BigInteger.ONE);
        Numbering.Num.AbstractNumId aid = F.createNumberingNumAbstractNumId();
        aid.setVal(absId);
        num.setAbstractNumId(aid);
        Numbering.Num.LvlOverride ov = F.createNumberingNumLvlOverride();
        ov.setIlvl(BigInteger.valueOf(ilvl));
        Numbering.Num.LvlOverride.StartOverride so = F.createNumberingNumLvlOverrideStartOverride();
        so.setVal(BigInteger.valueOf(startOverride));
        ov.setStartOverride(so);
        num.getLvlOverride().add(ov);
        numbering.getNum().add(num);
        return num.getNumId();
    }

    /** 添加带自动编号的段落（直接 numPr） */
    static void numberedPara(WordprocessingMLPackage pkg, BigInteger numId, int ilvl, String text) {
        P p = F.createP();
        PPr ppr = F.createPPr();
        p.setPPr(ppr);
        PPrBase.NumPr numPr = F.createPPrBaseNumPr();
        PPrBase.NumPr.NumId nid = F.createPPrBaseNumPrNumId();
        nid.setVal(numId);
        numPr.setNumId(nid);
        PPrBase.NumPr.Ilvl il = F.createPPrBaseNumPrIlvl();
        il.setVal(BigInteger.valueOf(ilvl));
        numPr.setIlvl(il);
        ppr.setNumPr(numPr);
        addRun(p, text);
        body(pkg).getContent().add(p);
    }

    /** 添加普通段落 */
    static void plainPara(WordprocessingMLPackage pkg, String text) {
        P p = F.createP();
        addRun(p, text);
        body(pkg).getContent().add(p);
    }

    /** 添加带样式的段落 */
    static void styledPara(WordprocessingMLPackage pkg, String styleId, String text) {
        P p = F.createP();
        PPr ppr = F.createPPr();
        PPrBase.PStyle ps = F.createPPrBasePStyle();
        ps.setVal(styleId);
        ppr.setPStyle(ps);
        p.setPPr(ppr);
        addRun(p, text);
        body(pkg).getContent().add(p);
    }

    /** 添加携带编号定义的标题样式（模拟 Heading 链接多级列表） */
    static void addNumberedStyle(WordprocessingMLPackage pkg, String styleId,
                                 BigInteger numId, int ilvl) {
        Style st = F.createStyle();
        st.setStyleId(styleId);
        PPr g = F.createPPr();
        PPrBase.NumPr numPr = F.createPPrBaseNumPr();
        PPrBase.NumPr.NumId nid = F.createPPrBaseNumPrNumId();
        nid.setVal(numId);
        numPr.setNumId(nid);
        PPrBase.NumPr.Ilvl il = F.createPPrBaseNumPrIlvl();
        il.setVal(BigInteger.valueOf(ilvl));
        numPr.setIlvl(il);
        g.setNumPr(numPr);
        st.setPPr(g);
        stylesPart(pkg).getStyle().add(st);
    }

    /** 添加 rows x cols 表格（每个单元格一个空段），返回表格对象 */
    static Tbl addTable(WordprocessingMLPackage pkg, int rows, int cols) {
        Tbl tbl = F.createTbl();
        for (int r = 0; r < rows; r++) {
            Tr tr = F.createTr();
            for (int c = 0; c < cols; c++) {
                Tc tc = F.createTc();
                tc.getContent().add(F.createP());
                tr.getContent().add(tc);
            }
            tbl.getContent().add(tr);
        }
        body(pkg).getContent().add(tbl);
        return tbl;
    }

    /** 单元格设置文本（替换原有段落） */
    static void setCell(Tbl tbl, int r, int c, String text) {
        Tc tc = cell(tbl, r, c);
        tc.getContent().clear();
        P p = F.createP();
        addRun(p, text);
        tc.getContent().add(p);
    }

    /** 单元格追加一个段落（构造多段单元格） */
    static void appendCellParagraph(Tbl tbl, int r, int c, String text) {
        Tc tc = cell(tbl, r, c);
        P p = F.createP();
        addRun(p, text);
        tc.getContent().add(p);
    }

    /** 设置单元格横向合并跨列数并删除被合并的后续单元格 */
    static void mergeCells(Tbl tbl, int r, int c, int span) {
        Tr tr = (Tr) tbl.getContent().get(r);
        Tc tc = (Tc) tr.getContent().get(c);
        TcPr tcPr = tc.getTcPr();
        if (tcPr == null) {
            tcPr = F.createTcPr();
            tc.setTcPr(tcPr);
        }
        TcPrInner.GridSpan gs = F.createTcPrInnerGridSpan();
        gs.setVal(BigInteger.valueOf(span));
        tcPr.setGridSpan(gs);
        for (int k = 1; k < span; k++) {
            tr.getContent().remove(c + 1);
        }
    }

    /** 序列化再读回：模拟"从文件读取"的真实路径，同时刷新 docx4j 对象树 */
    static WordprocessingMLPackage roundTrip(WordprocessingMLPackage pkg) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            pkg.save(bos);
            return WordprocessingMLPackage.load(new ByteArrayInputStream(bos.toByteArray()));
        } catch (Exception e) {
            throw new IllegalStateException("round-trip failed", e);
        }
    }

    /** 转换为行列表（去掉末尾换行） */
    static List<String> toLines(WordprocessingMLPackage pkg) {
        String text = DocxToTextConverter.convert(roundTrip(pkg));
        if (text.endsWith("\n")) {
            text = text.substring(0, text.length() - 1);
        }
        return text.isEmpty() ? Collections.<String>emptyList() : Arrays.asList(text.split("\n", -1));
    }

    private static Body body(WordprocessingMLPackage pkg) {
        return pkg.getMainDocumentPart().getJaxbElement().getBody();
    }

    private static Tc cell(Tbl tbl, int r, int c) {
        Tr tr = (Tr) tbl.getContent().get(r);
        return (Tc) tr.getContent().get(c);
    }

    private static Numbering numbering(WordprocessingMLPackage pkg) {
        try {
            MainDocumentPart main = pkg.getMainDocumentPart();
            NumberingDefinitionsPart ndp = main.getNumberingDefinitionsPart();
            if (ndp == null) {
                ndp = new NumberingDefinitionsPart();
                ndp.setJaxbElement(F.createNumbering());
                main.addTargetPart(ndp);
            }
            return ndp.getJaxbElement();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static org.docx4j.wml.Styles stylesPart(WordprocessingMLPackage pkg) {
        try {
            MainDocumentPart main = pkg.getMainDocumentPart();
            StyleDefinitionsPart sdp = main.getStyleDefinitionsPart();
            if (sdp == null) {
                sdp = new StyleDefinitionsPart();
                sdp.setJaxbElement(F.createStyles());
                main.addTargetPart(sdp);
            }
            return sdp.getJaxbElement();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /** 构造带文本的段落 */
    static P textParagraph(String text) {
        P p = F.createP();
        addRun(p, text);
        return p;
    }

    private static void addRun(P p, String text) {
        R run = F.createR();
        Text t = F.createText();
        t.setValue(text);
        t.setSpace("preserve");
        run.getContent().add(t);
        p.getContent().add(run);
    }
}
