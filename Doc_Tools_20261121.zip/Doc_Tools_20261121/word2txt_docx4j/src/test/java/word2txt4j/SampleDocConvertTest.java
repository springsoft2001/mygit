package word2txt4j;

import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.io.InputStream;
import java.util.Arrays;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.junit.jupiter.api.Test;

/**
 * 样例文档端到端：docx4j 版对 sample.docx 的输出必须与
 * word2txt（POI 版）的已验证输出完全一致（22 行）。
 */
class SampleDocConvertTest {

    @Test
    void 样例文档输出与POI版一致() throws Exception {
        String text;
        try (InputStream is = getClass().getResourceAsStream("/sample.docx")) {
            WordprocessingMLPackage pkg = WordprocessingMLPackage.load(is);
            text = DocxToTextConverter.convert(pkg);
        }
        String t = text.endsWith("\n") ? text.substring(0, text.length() - 1) : text;
        assertIterableEquals(Arrays.asList(
                "1 引言",
                "这是第一章下的正文段落，用于验证正文照常输出。",
                "1.1 研究背景",
                "背景部分的正文内容。",
                "1.1.1 背景细节",
                "三级标题下的正文内容。",
                "2 系统设计",
                "2.1 总体架构",
                "架构部分的正文内容。",
                "2.1.1 架构说明",
                "2.2 模块划分",
                "3.1 这是一个手动编号的小节（编号直接写在文本里）",
                "第一章 绪论",
                "第一章第一节 研究内容",
                "第二章 总结",
                "• 列表项一",
                "• 列表项二",
                "附录I 参考资料",
                "名称|说明|备注",
                "Word|微软文档格式|—",
                "|空单元格后的值|C2",
                "合并两列||尾部"),
                Arrays.asList(t.split("\n", -1)));
    }
}
