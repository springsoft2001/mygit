package word2txt4j;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/** NumberFormatter 单元测试：各 numFmt 的渲染规则（与 POI 版同用例）。 */
class NumberFormatterTest {

    @Test
    void decimalAndUnknownFallback() {
        assertEquals("42", NumberFormatter.format(42, "decimal"));
        assertEquals("7", NumberFormatter.format(7, "someFutureFormat"));
        assertEquals("3", NumberFormatter.format(3, null));
    }

    @Test
    void upperLetter() {
        assertEquals("A", NumberFormatter.format(1, "upperLetter"));
        assertEquals("Z", NumberFormatter.format(26, "upperLetter"));
        assertEquals("AA", NumberFormatter.format(27, "upperLetter"));
        assertEquals("AZ", NumberFormatter.format(52, "upperLetter"));
        assertEquals("ZZ", NumberFormatter.format(702, "upperLetter"));
    }

    @Test
    void lowerLetter() {
        assertEquals("c", NumberFormatter.format(3, "lowerLetter"));
        assertEquals("z", NumberFormatter.format(26, "lowerLetter"));
        assertEquals("aa", NumberFormatter.format(27, "lowerLetter"));
    }

    @Test
    void upperRoman() {
        assertEquals("I", NumberFormatter.format(1, "upperRoman"));
        assertEquals("IV", NumberFormatter.format(4, "upperRoman"));
        assertEquals("IX", NumberFormatter.format(9, "upperRoman"));
        assertEquals("XIV", NumberFormatter.format(14, "upperRoman"));
        assertEquals("XL", NumberFormatter.format(40, "upperRoman"));
        assertEquals("XC", NumberFormatter.format(90, "upperRoman"));
        assertEquals("CD", NumberFormatter.format(400, "upperRoman"));
        assertEquals("MCMLXXXVII", NumberFormatter.format(1987, "upperRoman"));
        assertEquals("MMMCMXCIX", NumberFormatter.format(3999, "upperRoman"));
    }

    @Test
    void romanOutOfRangeFallsBackToDecimal() {
        assertEquals("0", NumberFormatter.format(0, "upperRoman"));
        assertEquals("4000", NumberFormatter.format(4000, "upperRoman"));
    }

    @Test
    void lowerRoman() {
        assertEquals("xiv", NumberFormatter.format(14, "lowerRoman"));
    }

    @Test
    void decimalZero() {
        assertEquals("01", NumberFormatter.format(1, "decimalZero"));
        assertEquals("09", NumberFormatter.format(9, "decimalZero"));
        assertEquals("99", NumberFormatter.format(99, "decimalZero"));
        assertEquals("100", NumberFormatter.format(100, "decimalZero"));
    }

    @Test
    void chineseLowercase() {
        assertEquals("一", NumberFormatter.format(1, "chineseCountingThousand"));
        assertEquals("十", NumberFormatter.format(10, "chineseCounting"));
        assertEquals("十二", NumberFormatter.format(12, "chineseCounting"));
        assertEquals("二十", NumberFormatter.format(20, "chineseCounting"));
        assertEquals("二十一", NumberFormatter.format(21, "chineseCounting"));
        assertEquals("一百", NumberFormatter.format(100, "chineseCounting"));
        assertEquals("一百零一", NumberFormatter.format(101, "chineseCounting"));
        assertEquals("一百零五", NumberFormatter.format(105, "chineseCounting"));
        assertEquals("一百一十", NumberFormatter.format(110, "chineseCounting"));
        assertEquals("一千", NumberFormatter.format(1000, "chineseCounting"));
        assertEquals("一千零一十", NumberFormatter.format(1010, "chineseCounting"));
        assertEquals("一千一百", NumberFormatter.format(1100, "chineseCounting"));
        assertEquals("九千九百九十九", NumberFormatter.format(9999, "chineseCounting"));
        assertEquals("十四", NumberFormatter.format(14, "chineseCounting"));
    }

    @Test
    void chineseLegalUppercase() {
        assertEquals("壹", NumberFormatter.format(1, "chineseLegalSimplified"));
        // 财务大写不省略"壹"：10 = 壹拾（区别于小写"十"）
        assertEquals("壹拾", NumberFormatter.format(10, "chineseLegalSimplified"));
        assertEquals("壹拾贰", NumberFormatter.format(12, "chineseLegalSimplified"));
        assertEquals("壹佰零伍", NumberFormatter.format(105, "chineseLegalSimplified"));
    }

    @Test
    void chineseOutOfRangeFallsBackToDecimal() {
        assertEquals("10000", NumberFormatter.format(10000, "chineseCounting"));
        assertEquals("零", NumberFormatter.format(0, "chineseCounting"));
    }
}
