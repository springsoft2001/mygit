package word2txt4j;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * 真实文档端到端测试：《劳动者劳动合同.docx》（docx4j 版，与 POI 版同用例）。
 *
 * 文档实测结构（见 word2txt/docs/设计文档.md 5.1 节）：
 * - 10 个章标题为自动编号（chineseCountingThousand，模板 "%1、"）
 * - 1 个条款为自动编号（chineseCounting，模板 "第%1条"，start=14）
 * - 其余 第X条/一、二、 均为手动文本
 * - 无表格
 */
class LaborContractConvertTest {

    private static String text;
    private static List<String> lines;

    @BeforeAll
    static void convertDocument() throws Exception {
        try (InputStream is = LaborContractConvertTest.class
                .getResourceAsStream("/labor_contract.docx")) {
            WordprocessingMLPackage pkg = WordprocessingMLPackage.load(is);
            text = DocxToTextConverter.convert(pkg);
        }
        String t = text.endsWith("\n") ? text.substring(0, text.length() - 1) : text;
        lines = Arrays.asList(t.split("\n"));
    }

    @Test
    void 十个自动中文章编号完整还原() {
        assertTrue(text.contains("一、 劳动合同期限"));
        assertTrue(text.contains("二、 工作内容（岗位）和工作地点"));
        assertTrue(text.contains("三、 工作时间和休息休假"));
        assertTrue(text.contains("四、 劳动报酬及支付"));
        assertTrue(text.contains("五、 社会保险和福利待遇"));
        assertTrue(text.contains("六、 职业培训和劳动保护"));
        assertTrue(text.contains("七、 劳动合同的履行、变更、解除、终止"));
        assertTrue(text.contains("八、 双方约定事项"));
        assertTrue(text.contains("九、 劳动争议处理"));
        assertTrue(text.contains("十、 其他"));
    }

    @Test
    void start14的自动条款编号还原为第十四条() {
        // numId=1：chineseCounting，"第%1条"，w:start=14
        assertTrue(lines.stream().anyMatch(l ->
                l.startsWith("第十四条 乙方在多平台工作")),
                "应计算出起始值为 14 的自动编号：第十四条");
    }

    @Test
    void 手动编号条款原样保留() {
        assertTrue(lines.stream().anyMatch(l ->
                l.startsWith("第一条") && l.contains("甲乙双方自用工之日起建立劳动关系")));
        // 附件2中的手动"第十四条"必须与自动计算的"第十四条"共存且不重复加前缀
        assertTrue(lines.stream().anyMatch(l ->
                l.startsWith("第十四条") && l.contains("甲方负有保障乙方职业安全卫生")));
        assertFalse(lines.stream().anyMatch(l -> l.startsWith("第十四条 第十四条")),
                "手动编号段落不得被重复添加自动编号前缀");
    }

    @Test
    void 附件章节标题的手动编号保持原样() {
        // 附件2/3 的"一、主要权利义务"为手动文本（编号后无空格），与正文的自动编号"一、 "可区分
        assertTrue(text.contains("一、主要权利义务"));
        assertTrue(text.contains("附件2"));
        assertTrue(text.contains("新就业形态劳动者书面协议参考文本"));
    }

    @Test
    void 文档无表格输出不含竖线() {
        assertFalse(text.contains("|"), "该文档无表格，输出不应包含 | 分隔符");
    }

    @Test
    void 正文内容完整输出() {
        assertTrue(lines.size() > 250, "全文行数应大于 250，实际 " + lines.size());
        assertTrue(text.contains("根据《中华人民共和国劳动法》《中华人民共和国劳动合同法》"));
        assertTrue(text.contains("本合同一式两份，甲乙双方各执一份"));
    }
}
