package word2txt4j;

import java.util.List;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.wml.Body;
import org.docx4j.wml.Br;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.TcPr;
import org.docx4j.wml.Text;
import org.docx4j.wml.Tr;

import jakarta.xml.bind.JAXBElement;

/**
 * .docx -> 纯文本 转换器（docx4j 版）。转换规则与 word2txt（POI 版）一致：
 *
 * - 按文档顺序遍历正文（段落与表格交错）
 * - 段落：自动编号还原为 "编号 + 空格 + 文本"；空段跳过
 * - 表格：一行作为一个自然段，单元格之间用 "|" 分隔；
 *   横向合并(gridSpan)展开为空列以保持列对齐；单元格内多段合并为一行
 */
public final class DocxToTextConverter {

    private DocxToTextConverter() {
    }

    public static String convert(WordprocessingMLPackage pkg) {
        StringBuilder out = new StringBuilder();
        NumberingEngine engine = new NumberingEngine(pkg);
        Body body = pkg.getMainDocumentPart().getJaxbElement().getBody();
        appendBody(body.getContent(), engine, out);
        return out.toString();
    }

    private static void appendBody(List<Object> content, NumberingEngine engine,
                                   StringBuilder out) {
        for (Object raw : content) {
            Object o = unwrap(raw);
            if (o instanceof P) {
                String line = paragraphLine((P) o, engine);
                if (!line.isEmpty()) {
                    out.append(line).append('\n');
                }
            } else if (o instanceof Tbl) {
                appendTable((Tbl) o, engine, out);
            }
        }
    }

    /** 段落 -> 一行文本；自动编号的段落还原为 "编号 + 空格 + 文本" */
    static String paragraphLine(P p, NumberingEngine engine) {
        String text = extractText(p).replace('\u00A0', ' ').trim();
        String num = engine.numberFor(p);
        if (num == null || num.isEmpty()) {
            return text;
        }
        return num + " " + text;
    }

    /** 递归抽取文本：w:t 原样，w:tab -> \t，w:br -> \n，其余容器递归；
     *  注意 docx4j 反序列化后 run 内的 t/tab/br 包裹在 JAXBElement 中，需先解包 */
    private static String extractText(Object parent) {
        return extractTextList(((ContentAccessor) parent).getContent());
    }

    /** 解开 JAXBElement 包装（docx4j 对多种子元素使用 @XmlElementRef 包装） */
    private static Object unwrap(Object o) {
        return (o instanceof JAXBElement) ? ((JAXBElement<?>) o).getValue() : o;
    }

    private static String extractTextList(List<Object> content) {
        StringBuilder sb = new StringBuilder();
        for (Object raw : content) {
            Object o = unwrap(raw);
            if (o == null) {
                continue;
            }
            if (o instanceof Text) {
                sb.append(((Text) o).getValue());
            } else if (o instanceof R.Tab) {
                sb.append('\t');
            } else if (o instanceof Br) {
                sb.append('\n');
            } else if (o instanceof ContentAccessor) {
                sb.append(extractTextList(((ContentAccessor) o).getContent()));
            }
        }
        return sb.toString();
    }

    /** 表格 -> 每行一个自然段，单元格之间用 | 分隔 */
    private static void appendTable(Tbl table, NumberingEngine engine, StringBuilder out) {
        for (Object rawRow : table.getContent()) {
            Object ro = unwrap(rawRow);
            if (!(ro instanceof Tr)) {
                continue;
            }
            StringBuilder sb = new StringBuilder();
            boolean first = true;
            boolean hasContent = false;
            for (Object rawCell : ((Tr) ro).getContent()) {
                Object co = unwrap(rawCell);
                if (!(co instanceof Tc)) {
                    continue;
                }
                Tc cell = (Tc) co;
                if (!first) {
                    sb.append('|');
                }
                String cellTxt = cellText(cell, engine);
                if (!cellTxt.isEmpty()) {
                    hasContent = true;
                }
                sb.append(cellTxt);
                first = false;
                int span = gridSpan(cell);
                for (int k = 1; k < span; k++) {
                    sb.append('|');
                }
            }
            if (hasContent) {
                out.append(sb).append('\n');
            }
        }
    }

    /** 单元格内多段合并为一行（空格连接）；嵌套表格平铺 */
    private static String cellText(Tc cell, NumberingEngine engine) {
        StringBuilder sb = new StringBuilder();
        for (Object raw : cell.getContent()) {
            Object o = unwrap(raw);
            if (o instanceof P) {
                String s = paragraphLine((P) o, engine);
                if (!s.isEmpty()) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(s);
                }
            } else if (o instanceof Tbl) {
                StringBuilder nested = new StringBuilder();
                appendTable((Tbl) o, engine, nested);
                String s = nested.toString().replace('\n', ' ').trim();
                if (!s.isEmpty()) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(s);
                }
            }
        }
        return sb.toString().replace('\t', ' ').replace('\n', ' ').trim();
    }

    /** 横向合并跨列数（w:gridSpan），默认 1 */
    private static int gridSpan(Tc cell) {
        TcPr pr = cell.getTcPr();
        if (pr == null || pr.getGridSpan() == null || pr.getGridSpan().getVal() == null) {
            return 1;
        }
        return Math.max(1, pr.getGridSpan().getVal().intValue());
    }
}
