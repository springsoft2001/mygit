package word2txt;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFNum;
import org.apache.poi.xwpf.usermodel.XWPFNumbering;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFStyle;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFAbstractNum;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTAbstractNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPrGeneral;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTStyle;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STNumberFormat;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STStyleType;

/**
 * 测试固定装置：用 POI 以编程方式构造带编号/样式/表格的 docx 内存文档。
 */
final class DocxFixture {

    /** 一个编号级别的定义参数 */
    static class Lvl {
        final String numFmt;
        final String lvlText;
        final long start;
        final Integer lvlRestart; // null = 不设置

        Lvl(String numFmt, String lvlText, long start, Integer lvlRestart) {
            this.numFmt = numFmt;
            this.lvlText = lvlText;
            this.start = start;
            this.lvlRestart = lvlRestart;
        }

        static Lvl of(String numFmt, String lvlText) {
            return new Lvl(numFmt, lvlText, 1, null);
        }
    }

    private static BigInteger nextAbsId = BigInteger.valueOf(1000);
    private static BigInteger nextNumId = BigInteger.valueOf(1);

    private DocxFixture() {
    }

    /** 添加 abstractNum 定义，返回其 abstractNumId */
    static BigInteger addAbstractNum(XWPFDocument doc, Lvl... lvls) {
        XWPFNumbering numbering = numbering(doc);
        CTAbstractNum abs = CTAbstractNum.Factory.newInstance();
        abs.setAbstractNumId(nextAbsId);
        nextAbsId = nextAbsId.add(BigInteger.ONE);
        for (int i = 0; i < lvls.length; i++) {
            CTLvl lvl = abs.addNewLvl();
            lvl.setIlvl(BigInteger.valueOf(i));
            lvl.addNewStart().setVal(BigInteger.valueOf(lvls[i].start));
            lvl.addNewNumFmt().setVal(STNumberFormat.Enum.forString(lvls[i].numFmt));
            lvl.addNewLvlText().setVal(lvls[i].lvlText);
            if (lvls[i].lvlRestart != null) {
                lvl.addNewLvlRestart().setVal(BigInteger.valueOf(lvls[i].lvlRestart));
            }
        }
        numbering.addAbstractNum(new XWPFAbstractNum(abs));
        return abs.getAbstractNumId();
    }

    /** num -> abstractNum 映射，返回 numId */
    static BigInteger addNum(XWPFDocument doc, BigInteger absId) {
        XWPFNumbering numbering = numbering(doc);
        CTNum num = CTNum.Factory.newInstance();
        num.setNumId(nextNumId);
        nextNumId = nextNumId.add(BigInteger.ONE);
        num.addNewAbstractNumId().setVal(absId);
        numbering.addNum(new XWPFNum(num));
        return num.getNumId();
    }

    /** 带 lvlOverride/startOverride 的 num，返回 numId */
    static BigInteger addNumWithStartOverride(XWPFDocument doc, BigInteger absId,
                                              int ilvl, long startOverride) {
        XWPFNumbering numbering = numbering(doc);
        CTNum num = CTNum.Factory.newInstance();
        num.setNumId(nextNumId);
        nextNumId = nextNumId.add(BigInteger.ONE);
        num.addNewAbstractNumId().setVal(absId);
        CTNumLvl ov = num.addNewLvlOverride();
        ov.setIlvl(BigInteger.valueOf(ilvl));
        ov.addNewStartOverride().setVal(BigInteger.valueOf(startOverride));
        numbering.addNum(new XWPFNum(num));
        return num.getNumId();
    }

    /** 添加带自动编号的段落（直接 numPr） */
    static void numberedPara(XWPFDocument doc, BigInteger numId, int ilvl, String text) {
        XWPFParagraph p = doc.createParagraph();
        CTNumPr numPr = p.getCTP().addNewPPr().addNewNumPr();
        numPr.addNewNumId().setVal(numId);
        numPr.addNewIlvl().setVal(BigInteger.valueOf(ilvl));
        p.createRun().setText(text);
    }

    /** 添加普通段落 */
    static void plainPara(XWPFDocument doc, String text) {
        XWPFParagraph p = doc.createParagraph();
        p.createRun().setText(text);
    }

    /** 添加带样式的段落 */
    static void styledPara(XWPFDocument doc, String styleId, String text) {
        XWPFParagraph p = doc.createParagraph();
        p.setStyle(styleId);
        p.createRun().setText(text);
    }

    /** 添加携带编号定义的标题样式（模拟 Heading 链接多级列表） */
    static void addNumberedStyle(XWPFDocument doc, String styleId, BigInteger numId, int ilvl) {
        XWPFStyles styles = doc.createStyles();
        CTStyle ct = CTStyle.Factory.newInstance();
        ct.setStyleId(styleId);
        ct.setType(STStyleType.PARAGRAPH);
        ct.addNewName().setVal(styleId);
        CTPPrGeneral pr = ct.addNewPPr();
        CTNumPr numPr = pr.addNewNumPr();
        numPr.addNewNumId().setVal(numId);
        numPr.addNewIlvl().setVal(BigInteger.valueOf(ilvl));
        styles.addStyle(new XWPFStyle(ct));
    }

    /** 单元格设置文本（替换默认空段） */
    static void setCell(XWPFTable table, int r, int c, String text) {
        XWPFTableCell cell = table.getRow(r).getCell(c);
        cell.removeParagraph(0);
        cell.setText(text);
    }

    /** 单元格追加一个段落（构造多段单元格） */
    static void appendCellParagraph(XWPFTable table, int r, int c, String text) {
        XWPFTableCell cell = table.getRow(r).getCell(c);
        XWPFParagraph p = cell.addParagraph();
        p.createRun().setText(text);
    }

    /** 设置单元格横向合并跨列数并删除被合并的后续单元格（CT 层操作） */
    static void mergeCells(XWPFTable table, int r, int c, int span) {
        XWPFTableRow row = table.getRow(r);
        XWPFTableCell cell = row.getCell(c);
        CTTcPr pr = cell.getCTTc().isSetTcPr()
                ? cell.getCTTc().getTcPr() : cell.getCTTc().addNewTcPr();
        pr.addNewGridSpan().setVal(BigInteger.valueOf(span));
        for (int k = 1; k < span; k++) {
            row.getCtRow().removeTc(c + 1);
        }
    }

    /** 序列化再读回：模拟"从文件读取"的真实路径，同时刷新 POI 对象树 */
    static XWPFDocument roundTrip(XWPFDocument doc) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            doc.write(bos);
            return new XWPFDocument(new ByteArrayInputStream(bos.toByteArray()));
        } catch (Exception e) {
            throw new IllegalStateException("round-trip failed", e);
        }
    }

    /** 转换为行列表（去掉末尾换行） */
    static List<String> toLines(XWPFDocument doc) {
        String text = DocxToTextConverter.convert(roundTrip(doc));
        if (text.endsWith("\n")) {
            text = text.substring(0, text.length() - 1);
        }
        return text.isEmpty() ? Collections.<String>emptyList() : Arrays.asList(text.split("\n"));
    }

    private static XWPFNumbering numbering(XWPFDocument doc) {
        XWPFNumbering n = doc.getNumbering();
        return n != null ? n : doc.createNumbering();
    }
}
