package word2txt;

import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFNumbering;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFStyle;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.poi.xwpf.usermodel.XWPFAbstractNum;
import org.apache.poi.xwpf.usermodel.XWPFNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTAbstractNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPrGeneral;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTStyle;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STNumberFormat;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STStyleType;

/**
 * 生成用于端到端测试的 sample.docx：
 * - 数字多级编号（1 / 1.1 / 1.1.1，挂在 Heading1-3 样式上）
 * - 中文编号（第X章 / 第X章第X节）
 * - 项目符号、罗马数字附录（段落直接 numPr）
 * - 手动编号（编号直接写在文本里）
 * - 表格（含空单元格、横向合并单元格）
 */
public class SampleDocGenerator {

    private static BigInteger nextAbsId = BigInteger.valueOf(100);

    public static void main(String[] args) throws Exception {
        Path out = Paths.get(args.length > 0 ? args[0] : "sample.docx");

        XWPFDocument doc = new XWPFDocument();
        XWPFNumbering numbering = doc.createNumbering();

        // num1: 数字多级 1 / 1.1 / 1.1.1
        BigInteger abs0 = addAbstractNum(numbering,
                new String[]{"decimal", "decimal", "decimal"},
                new String[]{"%1", "%1.%2", "%1.%2.%3"});
        addNum(numbering, BigInteger.valueOf(1), abs0);
        // num2: 中文 第X章 / 第X章第X节
        BigInteger abs1 = addAbstractNum(numbering,
                new String[]{"chineseCountingThousand", "chineseCountingThousand"},
                new String[]{"第%1章", "第%1章第%2节"});
        addNum(numbering, BigInteger.valueOf(2), abs1);
        // num3: 项目符号
        BigInteger abs2 = addAbstractNum(numbering,
                new String[]{"bullet"}, new String[]{"\u2022"});
        addNum(numbering, BigInteger.valueOf(3), abs2);
        // num4: 罗马数字附录
        BigInteger abs3 = addAbstractNum(numbering,
                new String[]{"upperRoman"}, new String[]{"附录%1"});
        addNum(numbering, BigInteger.valueOf(4), abs3);

        // Heading1-3 样式携带 num1 编号（模拟 Word 多级列表链接到标题样式）
        XWPFStyles styles = doc.createStyles();
        addHeadingStyle(styles, "Heading1", "heading 1", 0);
        addHeadingStyle(styles, "Heading2", "heading 2", 1);
        addHeadingStyle(styles, "Heading3", "heading 3", 2);

        heading(doc, "Heading1", "引言");
        body(doc, "这是第一章下的正文段落，用于验证正文照常输出。");
        heading(doc, "Heading2", "研究背景");
        body(doc, "背景部分的正文内容。");
        heading(doc, "Heading3", "背景细节");
        body(doc, "三级标题下的正文内容。");
        heading(doc, "Heading1", "系统设计");
        heading(doc, "Heading2", "总体架构");
        body(doc, "架构部分的正文内容。");
        heading(doc, "Heading3", "架构说明");
        heading(doc, "Heading2", "模块划分"); // 验证 2.1.1 之后回到 2.2 的层级重置

        body(doc, "3.1 这是一个手动编号的小节（编号直接写在文本里）");

        // 中文编号（段落直接 numPr）
        numbered(doc, 2, 0, "绪论");
        numbered(doc, 2, 1, "研究内容");
        numbered(doc, 2, 0, "总结");

        // 项目符号
        numbered(doc, 3, 0, "列表项一");
        numbered(doc, 3, 0, "列表项二");

        // 罗马数字附录
        numbered(doc, 4, 0, "参考资料");

        // 表格：4 行 3 列，含空单元格与横向合并
        XWPFTable table = doc.createTable(4, 3);
        set(table, 0, 0, "名称");
        set(table, 0, 1, "说明");
        set(table, 0, 2, "备注");
        set(table, 1, 0, "Word");
        set(table, 1, 1, "微软文档格式");
        set(table, 1, 2, "—");
        set(table, 2, 0, ""); // 空单元格
        set(table, 2, 1, "空单元格后的值");
        set(table, 2, 2, "C2");
        // 第 4 行第一格横向合并 2 列（删除第 3 格）
        set(table, 3, 0, "合并两列");
        set(table, 3, 1, "尾部");
        XWPFTableCell merged = table.getRow(3).getCell(0);
        CTTcPr pr = merged.getCTTc().isSetTcPr()
                ? merged.getCTTc().getTcPr() : merged.getCTTc().addNewTcPr();
        pr.addNewGridSpan().setVal(BigInteger.valueOf(2));
        table.getRow(3).getCtRow().removeTc(2);

        try (OutputStream os = Files.newOutputStream(out)) {
            doc.write(os);
        }
        System.out.println("已生成: " + out.toAbsolutePath());
    }

    private static void heading(XWPFDocument doc, String style, String text) {
        XWPFParagraph p = doc.createParagraph();
        p.setStyle(style);
        p.createRun().setText(text);
    }

    private static void body(XWPFDocument doc, String text) {
        XWPFParagraph p = doc.createParagraph();
        p.createRun().setText(text);
    }

    private static void numbered(XWPFDocument doc, int numId, int ilvl, String text) {
        XWPFParagraph p = doc.createParagraph();
        CTNumPr numPr = p.getCTP().addNewPPr().addNewNumPr();
        numPr.addNewNumId().setVal(BigInteger.valueOf(numId));
        numPr.addNewIlvl().setVal(BigInteger.valueOf(ilvl));
        p.createRun().setText(text);
    }

    private static void set(XWPFTable t, int r, int c, String text) {
        XWPFTableCell cell = t.getRow(r).getCell(c);
        cell.removeParagraph(0);
        cell.setText(text);
    }

    private static void addHeadingStyle(XWPFStyles styles, String id, String name, int lvl) {
        CTStyle ct = CTStyle.Factory.newInstance();
        ct.setStyleId(id);
        ct.setType(STStyleType.PARAGRAPH);
        ct.addNewName().setVal(name);
        CTPPrGeneral pr = ct.addNewPPr();
        CTNumPr numPr = pr.addNewNumPr();
        numPr.addNewNumId().setVal(BigInteger.ONE);
        numPr.addNewIlvl().setVal(BigInteger.valueOf(lvl));
        pr.addNewOutlineLvl().setVal(BigInteger.valueOf(lvl));
        styles.addStyle(new XWPFStyle(ct));
    }

    private static BigInteger addAbstractNum(XWPFNumbering numbering, String[] fmts,
                                             String[] texts) {
        CTAbstractNum abs = CTAbstractNum.Factory.newInstance();
        abs.setAbstractNumId(nextAbsId);
        nextAbsId = nextAbsId.add(BigInteger.ONE);
        for (int i = 0; i < fmts.length; i++) {
            CTLvl lvl = abs.addNewLvl();
            lvl.setIlvl(BigInteger.valueOf(i));
            lvl.addNewStart().setVal(BigInteger.ONE);
            lvl.addNewNumFmt().setVal(STNumberFormat.Enum.forString(fmts[i]));
            lvl.addNewLvlText().setVal(texts[i]);
        }
        numbering.addAbstractNum(new XWPFAbstractNum(abs));
        return abs.getAbstractNumId();
    }

    private static void addNum(XWPFNumbering numbering, BigInteger numId, BigInteger absId) {
        CTNum num = CTNum.Factory.newInstance();
        num.setNumId(numId);
        num.addNewAbstractNumId().setVal(absId);
        numbering.addNum(new XWPFNum(num));
    }
}
