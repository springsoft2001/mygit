package word2txt;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.junit.jupiter.api.Test;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTbl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTc;

/** DocxToTextConverter 测试：表格规则与段落规范化。 */
class DocxToTextConverterTest {

    @Test
    void 基础表格一行一自然段竖线分隔() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(2, 2);
        DocxFixture.setCell(t, 0, 0, "a");
        DocxFixture.setCell(t, 0, 1, "b");
        DocxFixture.setCell(t, 1, 0, "c");
        DocxFixture.setCell(t, 1, 1, "d");

        assertEquals(List.of("a|b", "c|d"), DocxFixture.toLines(doc));
    }

    @Test
    void 行首空单元格保留前导竖线() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(1, 2);
        DocxFixture.setCell(t, 0, 0, "");
        DocxFixture.setCell(t, 0, 1, "值");

        assertEquals(List.of("|值"), DocxFixture.toLines(doc));
    }

    @Test
    void 横向合并展开为空列保持对齐() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(2, 3);
        DocxFixture.setCell(t, 0, 0, "名称");
        DocxFixture.setCell(t, 0, 1, "说明");
        DocxFixture.setCell(t, 0, 2, "备注");
        DocxFixture.setCell(t, 1, 0, "x");
        DocxFixture.setCell(t, 1, 2, "z");
        DocxFixture.mergeCells(t, 1, 0, 2);

        assertEquals(List.of("名称|说明|备注", "x||z"), DocxFixture.toLines(doc));
    }

    @Test
    void 单元格内多段合并为一行() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(1, 2);
        DocxFixture.setCell(t, 0, 0, "第一段");
        DocxFixture.appendCellParagraph(t, 0, 0, "第二段");
        DocxFixture.setCell(t, 0, 1, "b");

        assertEquals(List.of("第一段 第二段|b"), DocxFixture.toLines(doc));
    }

    @Test
    void 空段落跳过() {
        XWPFDocument doc = new XWPFDocument();
        DocxFixture.plainPara(doc, "第一行");
        doc.createParagraph(); // 空段
        doc.createParagraph().createRun().setText("   "); // 空白段
        DocxFixture.plainPara(doc, "第二行");

        assertEquals(List.of("第一行", "第二行"), DocxFixture.toLines(doc));
    }

    @Test
    void 嵌套表格平铺进单元格() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(1, 2);
        DocxFixture.setCell(t, 0, 0, "外层");
        // 在 (0,1) 单元格内以 CT 层方式构造嵌套 1x2 表格
        XWPFTableCell cell = t.getRow(0).getCell(1);
        CTTbl ctTbl = cell.getCTTc().addNewTbl();
        CTRow ctRow = ctTbl.addNewTr();
        for (String v : new String[]{"n1", "n2"}) {
            CTTc c = ctRow.addNewTc();
            c.addNewP().addNewR().addNewT().setStringValue(v);
        }

        assertEquals(List.of("外层|n1|n2"), DocxFixture.toLines(doc));
    }

    @Test
    void 全空表格行跳过() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable t = doc.createTable(2, 2);
        DocxFixture.setCell(t, 0, 0, "a");
        DocxFixture.setCell(t, 0, 1, "b");
        // 第 2 行全部为空
        DocxFixture.setCell(t, 1, 0, "");
        DocxFixture.setCell(t, 1, 1, "");

        assertEquals(List.of("a|b"), DocxFixture.toLines(doc));
    }
}
