package word2txt;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFNum;
import org.apache.poi.xwpf.usermodel.XWPFNumbering;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFStyle;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFAbstractNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTAbstractNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNum;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumLvl;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTNumPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTStyle;

/**
 * Word 自动编号还原引擎。
 *
 * Word 中 "1.2.3 / 第一章 / （二）" 等自动编号并不存储在段落文本里，
 * 而是由 numbering.xml 中的定义（abstractNum/num/lvl）按文档顺序实时计算。
 * 本引擎按文档顺序维护计数器，重现 Word 的编号计算，从而还原原始章节号。
 *
 * 支持的特性：
 * - numId -> num -> abstractNum 解析，含 lvlOverride / startOverride 合并
 * - 段落直接编号(pPr/numPr) 与标题样式链继承编号(style -> basedOn 链)
 * - 多级计数器：浅层出现后重置深层（含 w:lvlRestart 指定触发级别）
 * - lvlText 模板替换（如 "%1.%2.%3" / "第%1章" / "(%1)"）
 * - numFmt 渲染：decimal / 中文(一二三、壹贰叁) / 罗马 / 字母 / bullet / none 等
 * - w:isLgl（各级均按阿拉伯数字显示）
 */
public class NumberingEngine {

    private static final Pattern PLACEHOLDER = Pattern.compile("%(\\d+)");

    private final XWPFDocument document;
    private final XWPFStyles styles;

    /** numId -> 级别定义（已合并 lvlOverride），下标即 ilvl，可能含 null */
    private final Map<BigInteger, List<LvlDef>> levelCache = new HashMap<>();
    /** numId -> (ilvl -> 当前计数值)，只记录已出现过的级别 */
    private final Map<BigInteger, Map<Integer, Long>> counters = new HashMap<>();
    /** "numId:ilvl" 是否已使用过（startOverride 只在首次使用时生效） */
    private final Set<String> everUsed = new HashSet<>();

    NumberingEngine(XWPFDocument document) {
        this.document = document;
        this.styles = document.getStyles();
    }

    /** 单个编号级别的定义 */
    private static class LvlDef {
        static final int RESTART_UNSET = Integer.MIN_VALUE;
        String numFmt = "decimal";
        String lvlText = "%1";
        long start = 1;
        Long startOverride;
        boolean isLgl;
        int lvlRestart = RESTART_UNSET;
    }

    /**
     * 计算段落的编号文本。
     * 返回 null 表示段落无编号；返回空串表示编号格式为 none。
     */
    public String numberFor(XWPFParagraph p) {
        CTPPr ppr = p.getCTP().getPPr();
        CTNumPr direct = (ppr != null && ppr.isSetNumPr()) ? ppr.getNumPr() : null;

        BigInteger numId = null;
        Integer ilvl = null;

        if (direct != null && direct.isSetNumId()) {
            BigInteger v = numVal(direct.getNumId());
            if (v == null || v.signum() <= 0) {
                return null; // numId=0 表示显式取消编号
            }
            numId = v;
        }
        if (direct != null && direct.isSetIlvl()) {
            BigInteger lv = numVal(direct.getIlvl());
            if (lv != null) {
                ilvl = lv.intValue();
            }
        }

        // 段落未直接指定 numId 时，沿标题样式链查找（Heading 样式常携带编号定义）
        if (numId == null) {
            CTNumPr fromStyle = styleNumPr(p);
            if (fromStyle != null && fromStyle.isSetNumId()) {
                BigInteger v = numVal(fromStyle.getNumId());
                if (v != null && v.signum() > 0) {
                    numId = v;
                    if (ilvl == null && fromStyle.isSetIlvl()) {
                        BigInteger lv = numVal(fromStyle.getIlvl());
                        if (lv != null) {
                            ilvl = lv.intValue();
                        }
                    }
                }
            }
        }
        if (numId == null) {
            return null;
        }
        return nextNumber(numId, ilvl == null ? 0 : ilvl);
    }

    /** 沿 basedOn 链查找样式里的 numPr */
    private CTNumPr styleNumPr(XWPFParagraph p) {
        String sid = p.getStyleID();
        if (sid == null || styles == null) {
            return null;
        }
        Set<String> seen = new HashSet<>();
        while (sid != null && seen.add(sid)) {
            XWPFStyle st = styles.getStyle(sid);
            if (st == null) {
                return null;
            }
            CTStyle ct = st.getCTStyle();
            if (ct != null && ct.isSetPPr() && ct.getPPr().isSetNumPr()) {
                return ct.getPPr().getNumPr();
            }
            sid = st.getBasisStyleID();
        }
        return null;
    }

    /** 取编号定义并推进计数器，返回渲染后的编号文本 */
    private String nextNumber(BigInteger numId, int ilvl) {
        List<LvlDef> levels = levelCache.get(numId);
        if (levels == null) {
            levels = resolveLevels(numId);
            if (levels == null) {
                levels = Collections.emptyList();
            }
            levelCache.put(numId, levels);
        }
        if (ilvl < 0 || ilvl >= levels.size()) {
            return null;
        }
        LvlDef def = levels.get(ilvl);
        if (def == null) {
            return null;
        }
        if ("none".equals(def.numFmt)) {
            return "";
        }
        if ("bullet".equals(def.numFmt)) {
            return def.lvlText == null || def.lvlText.isEmpty() ? "•" : def.lvlText;
        }

        Map<Integer, Long> ctr = counters.computeIfAbsent(numId, k -> new HashMap<>());
        Long cur = ctr.get(ilvl);
        long v;
        if (cur == null) {
            boolean firstEver = everUsed.add(numId + ":" + ilvl);
            // startOverride 仅在该 num 级别第一次使用时生效；中途回退重置仍用 w:start
            v = (firstEver && def.startOverride != null) ? def.startOverride : def.start;
        } else {
            v = cur + 1;
        }
        ctr.put(ilvl, v);

        // 浅层级别出现后，重置更深层级的计数
        for (int d = ilvl + 1; d < levels.size(); d++) {
            LvlDef dd = levels.get(d);
            if (dd == null) {
                continue;
            }
            if (dd.lvlRestart == LvlDef.RESTART_UNSET || dd.lvlRestart == ilvl) {
                ctr.remove(d);
            }
        }
        return render(def, levels, ctr, ilvl);
    }

    /** 将 lvlText 模板（如 "%1.%2.%3"、"第%1章"）渲染为编号文本 */
    private String render(LvlDef def, List<LvlDef> levels, Map<Integer, Long> ctr, int ilvl) {
        String template = def.lvlText == null || def.lvlText.isEmpty()
                ? "%" + (ilvl + 1) : def.lvlText;
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int idx = Integer.parseInt(m.group(1)) - 1; // %1 -> ilvl 0
            LvlDef ld = (idx >= 0 && idx < levels.size()) ? levels.get(idx) : null;
            Long c = ctr.get(idx);
            // 未出现过的浅层级别按其起始值渲染（与 Word 行为一致，如孤立二级标题显示 1.1）
            long value = (c != null) ? c : (ld != null ? ld.start : 1);
            String fmt = def.isLgl ? "decimal"
                    : (ld != null && ld.numFmt != null ? ld.numFmt : "decimal");
            m.appendReplacement(sb, Matcher.quoteReplacement(NumberFormatter.format(value, fmt)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** 解析 numId 对应的级别定义列表（abstractNum + lvlOverride 合并） */
    private List<LvlDef> resolveLevels(BigInteger numId) {
        XWPFNumbering numbering = document.getNumbering();
        if (numbering == null) {
            return null;
        }
        XWPFNum num = numbering.getNum(numId);
        if (num == null) {
            return null;
        }
        CTNum ctn = num.getCTNum();
        if (ctn == null || ctn.getAbstractNumId() == null
                || ctn.getAbstractNumId().getVal() == null) {
            return null;
        }
        BigInteger absId = ctn.getAbstractNumId().getVal();

        CTAbstractNum abs = null;
        for (XWPFAbstractNum a : numbering.getAbstractNums()) {
            if (a.getCTAbstractNum() != null
                    && absId.equals(a.getCTAbstractNum().getAbstractNumId())) {
                abs = a.getCTAbstractNum();
                break;
            }
        }
        if (abs == null) {
            return null;
        }

        LvlDef[] arr = new LvlDef[9];
        int max = -1;
        for (CTLvl lvl : abs.getLvlList()) {
            if (lvl.getIlvl() == null) {
                continue;
            }
            int i = lvl.getIlvl().intValue();
            if (i < 0 || i > 8) {
                continue;
            }
            arr[i] = toDef(lvl);
            max = Math.max(max, i);
        }
        if (max < 0) {
            return null;
        }

        // 合并 num 级别的 lvlOverride（startOverride 与完整 lvl 覆盖）
        for (CTNumLvl ov : ctn.getLvlOverrideList()) {
            // lvlOverride 的 ilvl 是属性，直接返回 BigInteger
            if (ov.getIlvl() == null) {
                continue;
            }
            int i = ov.getIlvl().intValue();
            if (i < 0 || i > 8) {
                continue;
            }
            if (ov.isSetStartOverride() && ov.getStartOverride() != null
                    && ov.getStartOverride().getVal() != null) {
                if (arr[i] == null) {
                    arr[i] = new LvlDef();
                }
                arr[i].startOverride = ov.getStartOverride().getVal().longValue();
            }
            CTLvl repl = ov.getLvl();
            if (repl != null) {
                arr[i] = toDef(repl);
            }
        }

        List<LvlDef> list = new ArrayList<>(max + 1);
        for (int i = 0; i <= max; i++) {
            list.add(arr[i]);
        }
        return list;
    }

    private static LvlDef toDef(CTLvl lvl) {
        LvlDef d = new LvlDef();
        if (lvl.isSetNumFmt() && lvl.getNumFmt() != null && lvl.getNumFmt().getVal() != null) {
            d.numFmt = lvl.getNumFmt().getVal().toString();
        }
        if (lvl.isSetLvlText() && lvl.getLvlText() != null && lvl.getLvlText().getVal() != null) {
            d.lvlText = lvl.getLvlText().getVal();
        }
        if (lvl.isSetStart() && lvl.getStart() != null && lvl.getStart().getVal() != null) {
            d.start = lvl.getStart().getVal().longValue();
        }
        d.isLgl = lvl.isSetIsLgl();
        if (lvl.isSetLvlRestart() && lvl.getLvlRestart() != null
                && lvl.getLvlRestart().getVal() != null) {
            d.lvlRestart = lvl.getLvlRestart().getVal().intValue();
        }
        return d;
    }

    private static BigInteger numVal(Object numEl) {
        if (numEl == null) {
            return null;
        }
        try {
            return (BigInteger) numEl.getClass().getMethod("getVal").invoke(numEl);
        } catch (Exception e) {
            return null;
        }
    }
}
