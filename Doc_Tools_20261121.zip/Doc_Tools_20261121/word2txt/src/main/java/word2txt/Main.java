package word2txt;

import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.poi.openxml4j.exceptions.NotOfficeXmlFileException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

/**
 * 命令行入口：
 *   java -jar word2txt.jar <input.docx> [output.txt]
 * 不指定 output.txt 时结果输出到控制台。
 */
public class Main {

    public static void main(String[] args) {
        // 屏蔽 log4j-api 找不到实现时的告警输出
        System.setProperty("log4j2.StatusLogger.level", "OFF");
        if (args.length < 1) {
            System.err.println("用法: java -jar word2txt.jar <input.docx> [output.txt]");
            System.exit(2);
        }
        Path in = Paths.get(args[0]);
        if (!Files.isRegularFile(in)) {
            System.err.println("文件不存在: " + in.toAbsolutePath());
            System.exit(2);
        }
        Path out = args.length >= 2 ? Paths.get(args[1]) : null;

        try (InputStream is = Files.newInputStream(in);
             XWPFDocument doc = new XWPFDocument(is)) {
            String text = DocxToTextConverter.convert(doc);
            if (out != null) {
                Files.write(out, text.getBytes(StandardCharsets.UTF_8));
                System.out.println("已写出: " + out.toAbsolutePath());
            } else {
                PrintStream ps = new PrintStream(System.out, true, "UTF-8");
                ps.print(text);
            }
        } catch (NotOfficeXmlFileException e) {
            System.err.println("输入不是 .docx (OOXML) 文件。若是老版 .doc，请先转换:");
            System.err.println("  soffice --headless --convert-to docx <文件.doc>");
            System.exit(1);
        } catch (Exception e) {
            System.err.println("处理失败: " + e);
            e.printStackTrace();
            System.exit(1);
        }
    }
}
