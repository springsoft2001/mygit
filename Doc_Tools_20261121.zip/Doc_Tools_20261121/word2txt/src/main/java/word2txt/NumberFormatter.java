package word2txt;

/**
 * 编号格式化：将计数值按 Word 的 numFmt 渲染为显示文本。
 * 覆盖常用格式：decimal、中文（一/壹两套）、罗马、字母等；
 * 未覆盖的格式回退为阿拉伯数字。
 */
final class NumberFormatter {

    private NumberFormatter() {
    }

    static String format(long v, String fmt) {
        if (fmt == null) {
            return Long.toString(v);
        }
        switch (fmt) {
            case "upperLetter":
                return letters(v, true);
            case "lowerLetter":
                return letters(v, false);
            case "upperRoman":
                return roman(v).toUpperCase();
            case "lowerRoman":
                return roman(v).toLowerCase();
            case "decimalZero":
                return (v >= 0 && v <= 99) ? String.format("%02d", v) : Long.toString(v);
            case "chineseCounting":
            case "chineseCountingThousand":
            case "ideographDigital":
            case "taiwaneseCounting":
            case "taiwaneseCountingThousand":
            case "japaneseCounting":
            case "japaneseDigitalTenThousand":
                return chinese(v, false);
            case "chineseLegalSimplified":
            case "ideographLegalSimplified":
            case "japaneseLegalSimplified":
                return chinese(v, true);
            default:
                return Long.toString(v);
        }
    }

    /** 1->A, 26->Z, 27->AA */
    private static String letters(long v, boolean upper) {
        if (v <= 0) {
            return Long.toString(v);
        }
        StringBuilder sb = new StringBuilder();
        long x = v;
        while (x > 0) {
            x--;
            sb.insert(0, (char) ('A' + (x % 26)));
            x /= 26;
        }
        return upper ? sb.toString() : sb.toString().toLowerCase();
    }

    private static String roman(long v) {
        if (v <= 0 || v > 3999) {
            return Long.toString(v);
        }
        int[] nums = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] sym = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        int x = (int) v;
        for (int i = 0; i < nums.length; i++) {
            while (x >= nums[i]) {
                sb.append(sym[i]);
                x -= nums[i];
            }
        }
        return sb.toString();
    }

    /** 中文数字（1~9999）：legal=false 小写（一、十、百），legal=true 大写（壹、拾、佰） */
    private static String chinese(long v, boolean legal) {
        if (v == 0) {
            return "零";
        }
        if (v < 0 || v > 9999) {
            return Long.toString(v);
        }
        String zero = "零";
        String[] dig = legal
                ? new String[]{"", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"}
                : new String[]{"", "一", "二", "三", "四", "五", "六", "七", "八", "九"};
        String[] unit = legal
                ? new String[]{"", "拾", "佰", "仟"}
                : new String[]{"", "十", "百", "千"};

        int x = (int) v;
        StringBuilder sb = new StringBuilder();
        boolean pendingZero = false;
        for (int pos = 3; pos >= 0; pos--) {
            int p = 1;
            for (int k = 0; k < pos; k++) {
                p *= 10;
            }
            int d = (x / p) % 10;
            if (d == 0) {
                if (sb.length() > 0) {
                    pendingZero = true;
                }
                continue;
            }
            if (pendingZero) {
                sb.append(zero);
                pendingZero = false;
            }
            // 小写习惯：开头的 "一十" 省略 "一"（10 -> 十，12 -> 十二）
            boolean leadingOneTen = (d == 1 && pos == 1 && !legal && sb.length() == 0);
            if (!leadingOneTen) {
                sb.append(dig[d]);
            }
            sb.append(unit[pos]);
        }
        return sb.toString();
    }
}
