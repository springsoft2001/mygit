package word2txt;

import java.util.List;

import org.apache.poi.xwpf.usermodel.BodyElementType;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;

/**
 * .docx -> 纯文本 转换器。
 *
 * - 按文档顺序遍历正文（段落与表格交错）
 * - 段落：自动编号还原为 "编号 + 空格 + 文本"；空段跳过
 * - 表格：一行作为一个自然段，单元格之间用 "|" 分隔；
 *   横向合并(gridSpan)展开为空列以保持列对齐；单元格内多段合并为一行
 */
public final class DocxToTextConverter {

    private DocxToTextConverter() {
    }

    public static String convert(XWPFDocument doc) {
        StringBuilder out = new StringBuilder();
        NumberingEngine engine = new NumberingEngine(doc);
        appendBody(doc.getBodyElements(), engine, out);
        return out.toString();
    }

    private static void appendBody(List<IBodyElement> elements, NumberingEngine engine,
                                   StringBuilder out) {
        for (IBodyElement el : elements) {
            if (el.getElementType() == BodyElementType.PARAGRAPH) {
                String line = paragraphLine((XWPFParagraph) el, engine);
                if (!line.isEmpty()) {
                    out.append(line).append('\n');
                }
            } else if (el.getElementType() == BodyElementType.TABLE) {
                appendTable((XWPFTable) el, engine, out);
            }
        }
    }

    /** 段落 -> 一行文本；自动编号的段落还原为 "编号 + 空格 + 文本" */
    static String paragraphLine(XWPFParagraph p, NumberingEngine engine) {
        String text = p.getText();
        if (text == null) {
            text = "";
        }
        text = text.replace('\u00A0', ' ').trim();
        String num = engine.numberFor(p);
        if (num == null || num.isEmpty()) {
            return text;
        }
        return num + " " + text;
    }

    /** 表格 -> 每行一个自然段，单元格之间用 | 分隔 */
    private static void appendTable(XWPFTable table, NumberingEngine engine, StringBuilder out) {
        for (XWPFTableRow row : table.getRows()) {
            StringBuilder sb = new StringBuilder();
            boolean first = true;
            boolean hasContent = false;
            for (XWPFTableCell cell : row.getTableCells()) {
                if (!first) {
                    sb.append('|');
                }
                String cellTxt = cellText(cell, engine);
                if (!cellTxt.isEmpty()) {
                    hasContent = true;
                }
                sb.append(cellTxt);
                first = false;
                int span = gridSpan(cell);
                for (int k = 1; k < span; k++) {
                    sb.append('|');
                }
            }
            if (hasContent) {
                out.append(sb).append('\n');
            }
        }
    }

    /** 单元格内多段合并为一行（空格连接）；嵌套表格平铺 */
    private static String cellText(XWPFTableCell cell, NumberingEngine engine) {
        StringBuilder sb = new StringBuilder();
        for (IBodyElement el : cell.getBodyElements()) {
            if (el.getElementType() == BodyElementType.PARAGRAPH) {
                String s = paragraphLine((XWPFParagraph) el, engine);
                if (!s.isEmpty()) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(s);
                }
            } else if (el.getElementType() == BodyElementType.TABLE) {
                StringBuilder nested = new StringBuilder();
                appendTable((XWPFTable) el, engine, nested);
                String s = nested.toString().replace('\n', ' ').trim();
                if (!s.isEmpty()) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(s);
                }
            }
        }
        return sb.toString().replace('\t', ' ').replace('\n', ' ').trim();
    }

    /** 横向合并跨列数（w:gridSpan），默认 1 */
    private static int gridSpan(XWPFTableCell cell) {
        CTTcPr pr = cell.getCTTc().getTcPr();
        if (pr == null || !pr.isSetGridSpan() || pr.getGridSpan() == null
                || pr.getGridSpan().getVal() == null) {
            return 1;
        }
        return Math.max(1, pr.getGridSpan().getVal().intValue());
    }
}
