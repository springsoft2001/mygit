@echo off
setlocal
rem ============================================================
rem word2txt (POI) build script
rem Usage:
rem   build.bat           full package (run all JUnit tests first)
rem   build.bat -fast     skip tests
rem Output: target\word2txt.jar (executable fat jar)
rem ============================================================
cd /d "%~dp0"

where mvn >nul 2>nul
if errorlevel 1 (
    echo [ERROR] mvn not found. Install Maven and add it to PATH.
    exit /b 1
)

set GOAL=clean package
if "%~1"=="-fast" set GOAL=clean package -DskipTests

echo [INFO] mvn %GOAL%
call mvn %GOAL%
if errorlevel 1 (
    echo [ERROR] build failed
    exit /b 1
)

if not exist target\word2txt.jar (
    echo [ERROR] target\word2txt.jar not found
    exit /b 1
)

for %%F in (target\word2txt.jar) do echo [OK] built: %%~fF  (%%~zF bytes)
echo.
echo Usage:
echo   java -jar target\word2txt.jar input.docx [output.txt]
endlocal
