package com.ragsearch.index;

import com.ragsearch.model.Chunk;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 倒排索引与语料统计：文档频率（df）、平均文档长度，提供 BM25 平滑 IDF。
 *
 * <p>idf(t) = ln(1 + (N - df + 0.5) / (df + 0.5))
 * <p>（Lucene / Okapi BM25 的标准平滑公式，恒为正，避免高频词出现负权重；
 * 该值即 TF-IDF 体系中的逆文档频率，未见过的词元具有最大区分度。）
 */
public class InvertedIndex {

    private final List<Chunk> chunks;
    private final Map<String, Integer> docFreq = new HashMap<>();
    private final double avgDocLen;

    public static InvertedIndex build(List<Chunk> chunks) {
        return new InvertedIndex(chunks);
    }

    private InvertedIndex(List<Chunk> chunks) {
        this.chunks = Collections.unmodifiableList(chunks);
        long totalTokens = 0;
        for (Chunk chunk : chunks) {
            totalTokens += chunk.length();
            for (String term : chunk.getTermFreq().keySet()) {
                docFreq.merge(term, 1, Integer::sum);
            }
        }
        this.avgDocLen = chunks.isEmpty() ? 0 : (double) totalTokens / chunks.size();
    }

    public List<Chunk> getChunks() {
        return chunks;
    }

    /** 分片总数 N */
    public int size() {
        return chunks.size();
    }

    /** 词元的文档频率 df */
    public int docFreq(String term) {
        return docFreq.getOrDefault(term, 0);
    }

    /** BM25 平滑 IDF（TF-IDF 逆文档频率） */
    public double idf(String term) {
        int df = docFreq(term);
        return Math.log(1.0 + (size() - df + 0.5) / (df + 0.5));
    }

    /** 平均文档长度（词元数），BM25 长度归一化使用 */
    public double avgDocLen() {
        return avgDocLen;
    }
}
