package com.ragsearch.extractor;

import com.ragsearch.index.InvertedIndex;
import com.ragsearch.model.Keyword;
import com.ragsearch.model.KeywordCombination;
import com.ragsearch.model.QueryAnalysis;
import com.ragsearch.text.Stopwords;
import com.ragsearch.text.Tokenizer;
import com.ragsearch.text.Tokenizer.Token;

import java.util.ArrayList;
import java.util.List;

/**
 * 关键词提取器：对自然语言问题完成
 * 归一化 -&gt; 停用词剔除 -&gt; 分词 -&gt; 关键词合并 -&gt; 关键词组合构建 的完整流程。
 *
 * <ol>
 *   <li>中文重叠二元词元中，位置连续（start 逐次 +1）的词元链合并为一个“最大关键词”，
 *       如 [大模, 模型] 合并为“大模型”；西文整词独立成关键词；</li>
 *   <li>关键词权重 = 组成词元 IDF 之和（区分度），权重高者更可能定位到目标分片；</li>
 *   <li>相邻关键词两两构建“关键词组合”，用于匹配阶段的临近共现加成；</li>
 *   <li>过滤规则：长度 &lt; 2 的碎片关键词（多为删词残留）、西文停用词。</li>
 * </ol>
 */
public class KeywordExtractor {

    private final InvertedIndex index;

    public KeywordExtractor(InvertedIndex index) {
        this.index = index;
    }

    /** 关键词提取与组合构建 */
    public QueryAnalysis extract(String question) {
        String filtered = Stopwords.strip(Tokenizer.normalize(question));
        List<Token> tokens = Tokenizer.tokenize(filtered);

        List<Keyword> keywords = new ArrayList<>();
        int runStart = 0;
        for (int i = 1; i <= tokens.size(); i++) {
            if (i == tokens.size() || !chainable(tokens.get(i - 1), tokens.get(i))) {
                Keyword keyword = buildKeyword(filtered, tokens, runStart, i);
                if (keyword != null) {
                    keywords.add(keyword);
                }
                runStart = i;
            }
        }

        List<KeywordCombination> combinations = new ArrayList<>();
        for (int i = 0; i + 1 < keywords.size(); i++) {
            combinations.add(new KeywordCombination(keywords.get(i), keywords.get(i + 1)));
        }
        return new QueryAnalysis(question, keywords, combinations);
    }

    /**
     * 两个词元是否可并入同一关键词：
     * 中文二元链要求 start 逐次 +1（重叠连续）；同类型西文词元要求位置紧邻。
     */
    private static boolean chainable(Token prev, Token next) {
        if (prev.cjk != next.cjk) {
            return false;
        }
        if (prev.cjk) {
            return next.start == prev.start + 1;
        }
        return next.start == prev.end;
    }

    /** 将 [from, to) 区间内的连续词元合并为一个关键词；无效关键词返回 null */
    private Keyword buildKeyword(String filtered, List<Token> tokens, int from, int to) {
        Token first = tokens.get(from);
        Token last = tokens.get(to - 1);
        String display = filtered.substring(first.start, last.end);
        if (display.length() < 2) {
            return null;
        }
        if (!first.cjk && Stopwords.isLatinStop(display)) {
            return null;
        }
        List<String> terms = new ArrayList<>(to - from);
        double weight = 0;
        for (int i = from; i < to; i++) {
            String term = tokens.get(i).term;
            terms.add(term);
            weight += index.idf(term);
        }
        return new Keyword(display, terms, weight, !first.cjk);
    }
}
