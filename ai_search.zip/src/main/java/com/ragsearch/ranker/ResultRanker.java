package com.ragsearch.ranker;

import com.ragsearch.model.MatchResult;
import com.ragsearch.model.SearchResult;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 结果排序器：按相关性总分降序排序，同分按分片先后（chunkId 升序）稳定排序，
 * 保证结果确定性；过滤零分（无任何命中）的结果并截取 Top-N。
 */
public class ResultRanker {

    private static final double EPS = 1e-9;

    /**
     * 排序并截取 Top-N。
     *
     * @param results 各分片的匹配结果
     * @param topN    返回条数上限（&lt;=0 返回空列表）
     * @return 按相关性降序的搜索结果（附带名次）
     */
    public List<SearchResult> rank(List<MatchResult> results, int topN) {
        List<MatchResult> sorted = new ArrayList<>(results);
        sorted.sort(Comparator
                .comparingDouble(MatchResult::getTotalScore).reversed()
                .thenComparingInt(r -> r.getChunk().getId()));

        List<SearchResult> top = new ArrayList<>();
        int limit = Math.max(0, topN);
        for (MatchResult result : sorted) {
            if (top.size() >= limit) {
                break;
            }
            if (result.getTotalScore() <= EPS) {
                continue;
            }
            top.add(new SearchResult(top.size() + 1, result));
        }
        return top;
    }
}
