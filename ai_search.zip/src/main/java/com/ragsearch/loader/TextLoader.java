package com.ragsearch.loader;

import com.ragsearch.model.Chunk;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * 文本加载器：读取 content.txt 并完成文本分片（按行/按段落）。
 *
 * <ul>
 *   <li>{@link ChunkMode#LINE} —— 每个非空行为一个分片（默认）；</li>
 *   <li>{@link ChunkMode#PARAGRAPH} —— 以空行为段落分隔，段内多行合并为一个分片。</li>
 * </ul>
 * 自动处理 UTF-8 BOM 与 Windows/Unix 行尾差异。
 */
public class TextLoader {

    public enum ChunkMode {
        /** 按行分片 */
        LINE,
        /** 按段落分片（空行分隔） */
        PARAGRAPH
    }

    private static final char BOM = '\uFEFF';

    /** 默认按行加载 */
    public List<Chunk> load(String path) {
        return load(path, ChunkMode.LINE);
    }

    public List<Chunk> load(String path, ChunkMode mode) {
        Path file = Paths.get(path);
        if (!Files.isRegularFile(file)) {
            throw new IllegalArgumentException("内容文件不存在: " + file.toAbsolutePath());
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("读取内容文件失败: " + file, e);
        }
        if (!lines.isEmpty() && !lines.get(0).isEmpty() && lines.get(0).charAt(0) == BOM) {
            lines.set(0, lines.get(0).substring(1));
        }
        return mode == ChunkMode.LINE ? chunkByLine(lines) : chunkByParagraph(lines);
    }

    private List<Chunk> chunkByLine(List<String> lines) {
        List<Chunk> chunks = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (!line.isEmpty()) {
                chunks.add(Chunk.of(chunks.size(), i + 1, i + 1, line));
            }
        }
        return chunks;
    }

    private List<Chunk> chunkByParagraph(List<String> lines) {
        List<Chunk> chunks = new ArrayList<>();
        int start = -1;
        StringBuilder buf = new StringBuilder();
        for (int i = 0; i <= lines.size(); i++) {
            boolean blank = i == lines.size() || lines.get(i).trim().isEmpty();
            if (!blank) {
                if (start < 0) {
                    start = i + 1;
                }
                if (buf.length() > 0) {
                    buf.append('\n');
                }
                buf.append(lines.get(i).trim());
            } else if (start >= 0) {
                chunks.add(Chunk.of(chunks.size(), start, i, buf.toString()));
                start = -1;
                buf.setLength(0);
            }
        }
        return chunks;
    }
}
