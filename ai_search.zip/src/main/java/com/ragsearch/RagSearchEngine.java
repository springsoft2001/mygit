package com.ragsearch;

import com.ragsearch.extractor.KeywordExtractor;
import com.ragsearch.index.InvertedIndex;
import com.ragsearch.loader.TextLoader;
import com.ragsearch.matcher.SearchMatcher;
import com.ragsearch.model.Chunk;
import com.ragsearch.model.MatchResult;
import com.ragsearch.model.QueryAnalysis;
import com.ragsearch.model.SearchResult;
import com.ragsearch.ranker.ResultRanker;

import java.util.ArrayList;
import java.util.List;

/**
 * RAG 关键词搜索引擎：串联四大核心组件，完成“问题 -&gt; 关键词提取 -&gt; 组合构建 -&gt; 检索匹配 -&gt; 相关性排序”的完整流程。
 *
 * <pre>
 * TextLoader（文本加载/分片） -&gt; InvertedIndex（语料统计/IDF）
 *      -&gt; KeywordExtractor（关键词提取 + 关键词组合构建）
 *      -&gt; SearchMatcher（BM25/TF-IDF + 匹配度计算）
 *      -&gt; ResultRanker（相关性排序）
 * </pre>
 */
public class RagSearchEngine {

    private final List<Chunk> chunks;
    private final InvertedIndex index;
    private final KeywordExtractor extractor;
    private final SearchMatcher matcher;
    private final ResultRanker ranker = new ResultRanker();

    public RagSearchEngine(String contentPath) {
        this(contentPath, TextLoader.ChunkMode.LINE);
    }

    public RagSearchEngine(String contentPath, TextLoader.ChunkMode mode) {
        this.chunks = new TextLoader().load(contentPath, mode);
        this.index = InvertedIndex.build(chunks);
        this.extractor = new KeywordExtractor(index);
        this.matcher = new SearchMatcher(index);
    }

    /** 查询分析：关键词提取 + 关键词组合构建 */
    public QueryAnalysis analyze(String question) {
        return extractor.extract(question);
    }

    /** 搜索：返回按相关性排序的 Top-N 结果 */
    public List<SearchResult> search(String question, int topN) {
        QueryAnalysis query = extractor.extract(question);
        List<MatchResult> matches = new ArrayList<>(chunks.size());
        for (Chunk chunk : chunks) {
            matches.add(matcher.match(chunk, query));
        }
        return ranker.rank(matches, topN);
    }

    /** 分片数量 */
    public int chunkCount() {
        return chunks.size();
    }
}
