package com.ragsearch.matcher;

import com.ragsearch.index.InvertedIndex;
import com.ragsearch.model.Chunk;
import com.ragsearch.model.Keyword;
import com.ragsearch.model.KeywordCombination;
import com.ragsearch.model.MatchResult;
import com.ragsearch.model.QueryAnalysis;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 搜索匹配器：综合关键词匹配度、BM25(TF-IDF) 权重与短语/组合加成，计算单个分片的得分。
 *
 * <p><b>总分 = BM25 得分 + 关键词短语得分 + 关键词组合得分 + 覆盖率加成</b>
 *
 * <ol>
 *   <li><b>BM25</b>（Okapi BM25，Lucene/Elasticsearch 关键词打分的业界标准，k1=1.2, b=0.75）：
 *       对查询全部原子词元求
 *       Σ idf(t) * tf * (k1+1) / (tf + k1*(1-b+b*|d|/avgdl))，
 *       其中 idf 即 TF-IDF 逆文档频率（平滑公式），兼顾词频饱和与文档长度归一化；</li>
 *   <li><b>关键词短语得分</b>：关键词在分片中整串命中按字符计分（中文 1.0/字，西文 0.5/字符），
 *       未整串命中时按最长可命中片段降级计分（滑动窗口，最低 2 字符）；</li>
 *   <li><b>关键词组合得分</b>：组合两端关键词在限定窗口（slop=12 字符）内共现时，
 *       按 COMBO_WEIGHT * (命中长度之和) 加成（参考 match_phrase slop 临近匹配）；</li>
 *   <li><b>覆盖率</b>：命中词元占查询词元的比例，即关键词匹配度。</li>
 * </ol>
 */
public class SearchMatcher {

    /** BM25 词频饱和参数（业界默认值） */
    public static final double K1 = 1.2;
    /** BM25 文档长度归一化参数（业界默认值） */
    public static final double B = 0.75;
    /** 中文关键词短语计分：每字符权重 */
    public static final double CJK_CHAR_WEIGHT = 1.0;
    /** 西文关键词短语计分：每字符权重（近似按音节折算） */
    public static final double LATIN_CHAR_WEIGHT = 0.5;
    /** 关键词组合临近共现加成权重 */
    public static final double COMBO_WEIGHT = 0.6;
    /** 关键词组合共现窗口（字符数） */
    public static final int COMBO_SLOP = 12;
    /** 关键词覆盖率加成权重 */
    public static final double COVERAGE_WEIGHT = 2.0;

    private final InvertedIndex index;

    public SearchMatcher(InvertedIndex index) {
        this.index = index;
    }

    /** 计算单个分片与查询的匹配结果 */
    public MatchResult match(Chunk chunk, QueryAnalysis query) {
        Set<String> queryTerms = uniqueTerms(query);

        double bm25 = 0;
        int matchedTerms = 0;
        if (!queryTerms.isEmpty()) {
            Map<String, Integer> tf = chunk.getTermFreq();
            double norm = K1 * (1 - B + B * chunk.length() / Math.max(1.0, index.avgDocLen()));
            for (String term : queryTerms) {
                Integer freq = tf.get(term);
                if (freq == null || freq == 0) {
                    continue;
                }
                matchedTerms++;
                bm25 += index.idf(term) * freq * (K1 + 1) / (freq + norm);
            }
        }
        double coverage = queryTerms.isEmpty() ? 0 : (double) matchedTerms / queryTerms.size();

        String text = chunk.getMatchText();
        double phraseScore = 0;
        List<String> matchedKeywords = new ArrayList<>();
        for (Keyword keyword : query.getKeywords()) {
            String piece = longestMatchedPiece(keyword.getDisplay(), text);
            if (piece != null) {
                phraseScore += (keyword.isLatin() ? LATIN_CHAR_WEIGHT : CJK_CHAR_WEIGHT) * piece.length();
                matchedKeywords.add(piece);
            }
        }

        double comboScore = 0;
        List<String> matchedCombos = new ArrayList<>();
        for (KeywordCombination combo : query.getCombinations()) {
            String piece1 = longestMatchedPiece(combo.getFirst().getDisplay(), text);
            String piece2 = longestMatchedPiece(combo.getSecond().getDisplay(), text);
            if (piece1 == null || piece2 == null) {
                continue;
            }
            int pos1 = text.indexOf(piece1);
            int pos2 = text.indexOf(piece2);
            int gap = pos2 >= pos1 ? pos2 - (pos1 + piece1.length()) : pos1 - (pos2 + piece2.length());
            if (gap <= COMBO_SLOP) {
                comboScore += COMBO_WEIGHT * (piece1.length() + piece2.length());
                matchedCombos.add(combo.label());
            }
        }

        double total = bm25 + phraseScore + comboScore + COVERAGE_WEIGHT * coverage;
        return new MatchResult(chunk, total, bm25, phraseScore, comboScore, coverage,
                matchedKeywords, matchedCombos);
    }

    /** 查询的全部原子词元（去重、保持语序） */
    private static Set<String> uniqueTerms(QueryAnalysis query) {
        Set<String> terms = new LinkedHashSet<>();
        for (Keyword keyword : query.getKeywords()) {
            terms.addAll(keyword.getTokens());
        }
        return terms;
    }

    /**
     * 关键词在分片文本中的最长可命中片段：
     * 优先整串命中；否则从长到短滑动窗口降级（最低 2 字符）；完全未命中返回 null。
     */
    static String longestMatchedPiece(String keyword, String text) {
        if (keyword == null || text == null || keyword.length() < 2) {
            return null;
        }
        if (text.contains(keyword)) {
            return keyword;
        }
        for (int len = keyword.length() - 1; len >= 2; len--) {
            for (int start = 0; start + len <= keyword.length(); start++) {
                String piece = keyword.substring(start, start + len);
                if (text.contains(piece)) {
                    return piece;
                }
            }
        }
        return null;
    }
}
