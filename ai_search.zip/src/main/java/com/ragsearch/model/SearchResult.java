package com.ragsearch.model;

import java.util.List;

/**
 * 最终排序后的搜索结果：名次 + 匹配详情 + 原文摘要。
 */
public class SearchResult {

    private final int rank;
    private final MatchResult match;

    public SearchResult(int rank, MatchResult match) {
        this.rank = rank;
        this.match = match;
    }

    public int getRank() {
        return rank;
    }

    public int getChunkId() {
        return match.getChunk().getId();
    }

    /** 命中分片在原文件中的起始行号（1 起） */
    public int getStartLine() {
        return match.getChunk().getStartLine();
    }

    public int getEndLine() {
        return match.getChunk().getEndLine();
    }

    public double getScore() {
        return match.getTotalScore();
    }

    public double getCoverage() {
        return match.getCoverage();
    }

    public double getBm25Score() {
        return match.getBm25Score();
    }

    public double getPhraseScore() {
        return match.getPhraseScore();
    }

    public double getComboScore() {
        return match.getComboScore();
    }

    public List<String> getMatchedKeywords() {
        return match.getMatchedKeywords();
    }

    public List<String> getMatchedCombos() {
        return match.getMatchedCombos();
    }

    public String getRawText() {
        return match.getChunk().getRawText();
    }

    /** 原文摘要（超长截断） */
    public String getSnippet(int maxChars) {
        String raw = match.getChunk().getRawText();
        return raw.length() <= maxChars ? raw : raw.substring(0, maxChars) + "……";
    }
}
