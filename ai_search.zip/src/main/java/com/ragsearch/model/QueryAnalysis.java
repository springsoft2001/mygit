package com.ragsearch.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 查询分析结果：关键词 + 关键词组合（均保持查询语序）。
 */
public class QueryAnalysis {

    private final String question;
    private final List<Keyword> keywords;
    private final List<KeywordCombination> combinations;

    public QueryAnalysis(String question, List<Keyword> keywords, List<KeywordCombination> combinations) {
        this.question = question;
        this.keywords = Collections.unmodifiableList(new ArrayList<>(keywords));
        this.combinations = Collections.unmodifiableList(new ArrayList<>(combinations));
    }

    public String getQuestion() {
        return question;
    }

    /** 提取出的关键词（查询语序） */
    public List<Keyword> getKeywords() {
        return keywords;
    }

    /** 关键词组合（查询语序的相邻关键词对） */
    public List<KeywordCombination> getCombinations() {
        return combinations;
    }

    /** 按区分度（IDF 权重）降序的 Top-N 关键词（展示用） */
    public List<Keyword> topKeywords(int n) {
        List<Keyword> sorted = new ArrayList<>(keywords);
        sorted.sort(Comparator.comparingDouble(Keyword::getWeight).reversed());
        return sorted.subList(0, Math.min(Math.max(n, 0), sorted.size()));
    }
}
