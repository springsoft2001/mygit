package com.ragsearch.model;

import com.ragsearch.text.Stopwords;
import com.ragsearch.text.Tokenizer;
import com.ragsearch.text.Tokenizer.Token;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 文本分片：检索的最小单位（一行或一个段落）。
 *
 * <p>构造时即完成归一化、停用词剔除、分词与词频（TF）统计，
 * 供倒排索引与匹配器直接使用，检索阶段无需重复计算。
 */
public class Chunk {

    private final int id;
    /** 原文件起始行号（1 起） */
    private final int startLine;
    private final int endLine;
    /** 原始文本（展示用） */
    private final String rawText;
    /** 归一化 + 剔除停用词后的文本（短语匹配用） */
    private final String matchText;
    private final List<Token> tokens;
    /** 词频表：term -> tf */
    private final Map<String, Integer> termFreq;

    public static Chunk of(int id, int startLine, int endLine, String rawText) {
        return new Chunk(id, startLine, endLine, rawText);
    }

    private Chunk(int id, int startLine, int endLine, String rawText) {
        this.id = id;
        this.startLine = startLine;
        this.endLine = endLine;
        this.rawText = rawText;
        this.matchText = Stopwords.strip(Tokenizer.normalize(rawText));
        this.tokens = Tokenizer.tokenize(matchText);
        Map<String, Integer> tf = new HashMap<>();
        for (Token t : tokens) {
            tf.merge(t.term, 1, Integer::sum);
        }
        this.termFreq = Collections.unmodifiableMap(tf);
    }

    public int getId() {
        return id;
    }

    public int getStartLine() {
        return startLine;
    }

    public int getEndLine() {
        return endLine;
    }

    public String getRawText() {
        return rawText;
    }

    public String getMatchText() {
        return matchText;
    }

    public List<Token> getTokens() {
        return tokens;
    }

    public Map<String, Integer> getTermFreq() {
        return termFreq;
    }

    /** 文档长度（词元数），BM25 长度归一化使用 */
    public int length() {
        return tokens.size();
    }
}
