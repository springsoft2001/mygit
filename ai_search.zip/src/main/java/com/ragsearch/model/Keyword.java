package com.ragsearch.model;

import java.util.Collections;
import java.util.List;

/**
 * 关键词：由查询中位置连续的原子词元合并而成的最大匹配单元（短语级关键词）。
 *
 * <p>例如“大模型的主要类别”剔除停用词“的”后，重叠二元链
 * [大模, 模型, 型主, 主要, 要类, 类别] 合并为关键词“大模型主要类别”。
 *
 * <p>weight 为组成词元 IDF 之和，衡量关键词的区分度（越罕见权重越高）。
 */
public class Keyword {

    private final String display;
    /** 组成该关键词的原子词元（中文重叠二元或西文整词） */
    private final List<String> tokens;
    private final double weight;
    private final boolean latin;

    public Keyword(String display, List<String> tokens, double weight, boolean latin) {
        this.display = display;
        this.tokens = Collections.unmodifiableList(tokens);
        this.weight = weight;
        this.latin = latin;
    }

    public String getDisplay() {
        return display;
    }

    public List<String> getTokens() {
        return tokens;
    }

    public double getWeight() {
        return weight;
    }

    public boolean isLatin() {
        return latin;
    }

    @Override
    public String toString() {
        return display;
    }
}
