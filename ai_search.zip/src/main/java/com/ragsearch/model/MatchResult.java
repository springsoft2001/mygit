package com.ragsearch.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 单个分片的匹配结果：相关性总分及各分项得分（用于排序与结果解释）。
 */
public class MatchResult {

    private final Chunk chunk;
    private final double totalScore;
    /** BM25(TF-IDF) 得分 */
    private final double bm25Score;
    /** 关键词短语得分 */
    private final double phraseScore;
    /** 关键词组合临近共现得分 */
    private final double comboScore;
    /** 关键词匹配覆盖率（命中词元 / 查询词元） */
    private final double coverage;
    private final List<String> matchedKeywords;
    private final List<String> matchedCombos;

    public MatchResult(Chunk chunk, double totalScore, double bm25Score, double phraseScore,
                       double comboScore, double coverage, List<String> matchedKeywords,
                       List<String> matchedCombos) {
        this.chunk = chunk;
        this.totalScore = totalScore;
        this.bm25Score = bm25Score;
        this.phraseScore = phraseScore;
        this.comboScore = comboScore;
        this.coverage = coverage;
        this.matchedKeywords = Collections.unmodifiableList(new ArrayList<>(matchedKeywords));
        this.matchedCombos = Collections.unmodifiableList(new ArrayList<>(matchedCombos));
    }

    public Chunk getChunk() {
        return chunk;
    }

    public double getTotalScore() {
        return totalScore;
    }

    public double getBm25Score() {
        return bm25Score;
    }

    public double getPhraseScore() {
        return phraseScore;
    }

    public double getComboScore() {
        return comboScore;
    }

    public double getCoverage() {
        return coverage;
    }

    /** 实际命中的关键词片段 */
    public List<String> getMatchedKeywords() {
        return matchedKeywords;
    }

    /** 实际命中（临近共现）的关键词组合 */
    public List<String> getMatchedCombos() {
        return matchedCombos;
    }
}
