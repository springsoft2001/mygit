package com.ragsearch.model;

/**
 * 关键词组合：查询中相邻出现的一对关键词（AND 语义）。
 *
 * <p>匹配器在两词于分片内临近共现（限定字符窗口）时给予额外加成，
 * 参考 Elasticsearch match_phrase 查询 slop 临近匹配的业界思想。
 */
public class KeywordCombination {

    private final Keyword first;
    private final Keyword second;

    public KeywordCombination(Keyword first, Keyword second) {
        this.first = first;
        this.second = second;
    }

    public Keyword getFirst() {
        return first;
    }

    public Keyword getSecond() {
        return second;
    }

    /** 组合展示名，如“大模型 + 主要类别” */
    public String label() {
        return first.getDisplay() + " + " + second.getDisplay();
    }

    @Override
    public String toString() {
        return label();
    }
}
