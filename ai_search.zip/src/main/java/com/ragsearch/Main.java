package com.ragsearch;

import com.ragsearch.model.Keyword;
import com.ragsearch.model.KeywordCombination;
import com.ragsearch.model.QueryAnalysis;
import com.ragsearch.model.SearchResult;

import java.util.List;

/**
 * 命令行入口（演示与手工验证用，无界面要求）。
 *
 * <pre>
 * mvn compile
 * java -cp target/classes com.ragsearch.Main "大模型的主要类别有哪些？"
 * </pre>
 * <p>无参数时运行内置演示问题。
 */
public class Main {

    private static final String CONTENT_FILE = "content.txt";
    private static final int TOP_N = 3;

    private static final String[] DEMO_QUESTIONS = {
            "什么是人工智能大模型？",
            "大模型的主要类别有哪些？",
            "大模型有什么特点？",
            "中国生成式人工智能用户规模是多少？"
    };

    public static void main(String[] args) {
        RagSearchEngine engine = new RagSearchEngine(CONTENT_FILE);
        if (args.length > 0) {
            searchAndPrint(engine, args[0]);
            return;
        }
        System.out.println("=== RAG 关键词搜索模块（纯 Java 实现，无外部依赖） ===");
        System.out.println("内容源: " + CONTENT_FILE + "，分片数: " + engine.chunkCount());
        System.out.println();
        for (String question : DEMO_QUESTIONS) {
            searchAndPrint(engine, question);
        }
        System.out.println("自定义搜索: java -cp target/classes com.ragsearch.Main \"你的问题\"");
    }

    private static void searchAndPrint(RagSearchEngine engine, String question) {
        QueryAnalysis analysis = engine.analyze(question);
        System.out.println("[问题] " + question);
        System.out.println("  提取关键词: " + formatKeywords(analysis));
        System.out.println("  关键词组合: " + formatCombos(analysis));

        List<SearchResult> results = engine.search(question, TOP_N);
        if (results.isEmpty()) {
            System.out.println("  搜索结果: （无匹配内容）");
        } else {
            System.out.println("  搜索结果 Top " + results.size() + ":");
            for (SearchResult r : results) {
                System.out.printf("    #%d 得分=%.2f (BM25=%.2f, 短语=%.2f, 组合=%.2f) 覆盖率=%.0f%% 命中=%s 来源=第%d行%n",
                        r.getRank(), r.getScore(), r.getBm25Score(), r.getPhraseScore(),
                        r.getComboScore(), r.getCoverage() * 100, r.getMatchedKeywords(),
                        r.getStartLine());
                System.out.println("      内容: " + r.getSnippet(120));
            }
        }
        System.out.println();
    }

    private static String formatKeywords(QueryAnalysis analysis) {
        if (analysis.getKeywords().isEmpty()) {
            return "无";
        }
        StringBuilder sb = new StringBuilder();
        for (Keyword kw : analysis.topKeywords(5)) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(kw.getDisplay()).append(String.format("(权重 %.2f)", kw.getWeight()));
        }
        return sb.toString();
    }

    private static String formatCombos(QueryAnalysis analysis) {
        if (analysis.getCombinations().isEmpty()) {
            return "无";
        }
        StringBuilder sb = new StringBuilder();
        for (KeywordCombination combo : analysis.getCombinations()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(combo.label());
        }
        return sb.toString();
    }
}
