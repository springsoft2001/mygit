package com.ragsearch.text;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 文本归一化与分词器（纯 Java，无第三方依赖）。
 *
 * <p>归一化规则（{@link #normalize}）：
 * <ol>
 *   <li>NFKC 规范化：全角字母/数字/标点折叠为半角（如“（）”“：”）；</li>
 *   <li>统一小写；</li>
 *   <li>中文与字母数字之外的字符（标点、空白、符号）折叠为单个空格，保留词边界。</li>
 * </ol>
 *
 * <p>分词规则（{@link #tokenize}，输入为归一化并剔除停用词后的文本）：
 * <ol>
 *   <li>中文连续段采用<b>重叠二元切分</b>（CJK Bigram，参考 Lucene CJKAnalyzer 的业界通行方案），
 *       如“大模型” -> [大模, 模型]，兼顾召回与实现简单性；</li>
 *   <li>字母/数字连续段作为整词，如 "tfidf" -> [tfidf]。</li>
 * </ol>
 */
public final class Tokenizer {

    /** 原子词元：词项 + 在归一化文本中的字符区间 [start, end) + 是否中文词元 */
    public static final class Token {
        public final String term;
        public final int start;
        public final int end;
        public final boolean cjk;

        Token(String term, int start, int end, boolean cjk) {
            this.term = term;
            this.start = start;
            this.end = end;
            this.cjk = cjk;
        }
    }

    private Tokenizer() {
    }

    /** 归一化：全半角折叠、小写化，标点/符号折叠为空格（保留词边界） */
    public static String normalize(String raw) {
        if (raw == null || raw.isEmpty()) {
            return "";
        }
        String s = Normalizer.normalize(raw, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder(s.length());
        boolean pendingSpace = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (isCjk(c) || isAlnum(c)) {
                if (pendingSpace && sb.length() > 0) {
                    sb.append(' ');
                }
                pendingSpace = false;
                sb.append(c);
            } else {
                pendingSpace = true;
            }
        }
        return sb.toString();
    }

    /** 分词：中文重叠二元 + 西文/数字整词 */
    public static List<Token> tokenize(String text) {
        List<Token> tokens = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return tokens;
        }
        int i = 0;
        int n = text.length();
        while (i < n) {
            char c = text.charAt(i);
            if (c == ' ') {
                i++;
                continue;
            }
            if (isCjk(c)) {
                int j = i;
                while (j < n && isCjk(text.charAt(j))) {
                    j++;
                }
                if (j - i == 1) {
                    tokens.add(new Token(text.substring(i, j), i, j, true));
                } else {
                    for (int s = i; s + 1 < j; s++) {
                        tokens.add(new Token(text.substring(s, s + 2), s, s + 2, true));
                    }
                }
                i = j;
            } else {
                int j = i;
                while (j < n && isAlnum(text.charAt(j))) {
                    j++;
                }
                tokens.add(new Token(text.substring(i, j), i, j, false));
                i = j;
            }
        }
        return tokens;
    }

    /** CJK 统一表意文字（含扩展 A 区） */
    static boolean isCjk(char c) {
        return (c >= 0x4E00 && c <= 0x9FFF) || (c >= 0x3400 && c <= 0x4DBF);
    }

    static boolean isAlnum(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
    }
}
