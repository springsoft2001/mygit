package com.ragsearch.text;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * 停用词表（查询侧与文档侧统一应用，保证两侧词元对齐）。
 *
 * <p>处理策略：
 * <ol>
 *   <li>短语级停用词（如“什么”“哪些”）：整体替换为空格 —— 切断词边界，避免污染相邻词；</li>
 *   <li>中文虚词单字（如“的”“了”“是”“有”）：直接删除（不引入空格）—— 虚词两侧语义黏合，
 *       使查询“大模型的主要类别”与文档“大模型的主要类别”在删除“的”后仍能整串短语匹配；</li>
 *   <li>西文停用词：在关键词构建阶段按整词过滤。</li>
 * </ol>
 */
public final class Stopwords {

    /**
     * 短语级停用词（按长度降序替换为空格，避免长词被短词子串误拆）。
     */
    private static final String[] PHRASE_STOPS = {
            "介绍一下", "有没有", "是否有", "为什么", "哪几个",
            "哪些", "哪个", "哪样", "怎样", "怎么", "如何", "为何", "多少", "几个",
            "请问", "麻烦", "帮我", "一下", "什么"
    };

    /** 中文虚词/代词单字：直接删除（不引入空格，保持前后语义黏合） */
    private static final String CJK_FUNCTION_CHARS =
            "的了是在和与及等对从被把给向于则之或有我你他她它吗呢吧啊呀哦嘛么嗯啦呗哇";

    private static final Set<String> LATIN_STOPS = new HashSet<>(Arrays.asList(
            "the", "a", "an", "of", "to", "for", "in", "on", "at", "is", "are", "was",
            "were", "be", "been", "being", "what", "which", "how", "why", "who", "whom",
            "whose", "when", "where", "do", "does", "did", "and", "or", "not", "no",
            "with", "that", "this", "these", "those", "it", "its", "as", "by", "from",
            "about", "into", "can", "could", "should", "would", "will", "shall", "may",
            "might", "must", "tell", "please", "me", "you", "your", "our", "their",
            "there", "here"));

    private Stopwords() {
    }

    /** 剔除停用词：短语停用词替换为空格，虚词单字直接删除 */
    public static String strip(String normalizedSpaced) {
        if (normalizedSpaced == null || normalizedSpaced.isEmpty()) {
            return "";
        }
        String s = normalizedSpaced;
        for (String phrase : PHRASE_STOPS) {
            if (s.contains(phrase)) {
                s = s.replace(phrase, " ");
            }
        }
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != ' ' && CJK_FUNCTION_CHARS.indexOf(c) >= 0) {
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    /** 西文停用词判断（按整词） */
    public static boolean isLatinStop(String term) {
        return LATIN_STOPS.contains(term);
    }
}
