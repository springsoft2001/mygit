package com.ragsearch.ranker;

import com.ragsearch.model.Chunk;
import com.ragsearch.model.MatchResult;
import com.ragsearch.model.SearchResult;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** 结果排序器测试：降序排序、同分稳定排序、零分过滤、Top-N 截断 */
class ResultRankerTest {

    private final ResultRanker ranker = new ResultRanker();

    private static MatchResult result(int chunkId, double score) {
        Chunk chunk = Chunk.of(chunkId, chunkId + 1, chunkId + 1, "分片 " + chunkId);
        return new MatchResult(chunk, score, score, 0, 0, 0, Collections.emptyList(), Collections.emptyList());
    }

    @Test
    void 按相关性降序排序() {
        List<SearchResult> ranked = ranker.rank(
                Arrays.asList(result(0, 5.0), result(1, 9.0), result(2, 7.0)), 3);

        assertEquals(3, ranked.size());
        assertEquals(1, ranked.get(0).getChunkId(), "最高分应排第一");
        assertEquals(2, ranked.get(1).getChunkId());
        assertEquals(0, ranked.get(2).getChunkId());
        assertEquals(1, ranked.get(0).getRank());
        assertEquals(2, ranked.get(1).getRank());
        assertEquals(3, ranked.get(2).getRank());
    }

    @Test
    void 同分时按分片先后稳定排序() {
        List<SearchResult> ranked = ranker.rank(
                Arrays.asList(result(0, 5.0), result(2, 9.0), result(1, 9.0), result(3, 5.0)), 4);

        assertEquals(Arrays.asList(1, 2, 0, 3),
                ranked.stream().map(SearchResult::getChunkId).collect(Collectors.toList()));
    }

    @Test
    void 零分结果被过滤() {
        List<SearchResult> ranked = ranker.rank(
                Arrays.asList(result(0, 0.0), result(1, 3.0), result(2, 0.0)), 3);

        assertEquals(1, ranked.size(), "无命中的零分结果不应返回");
        assertEquals(1, ranked.get(0).getChunkId());
    }

    @Test
    void TopN截断与非正参数() {
        List<SearchResult> ranked = ranker.rank(
                Arrays.asList(result(0, 5.0), result(1, 9.0), result(2, 7.0)), 2);
        assertEquals(2, ranked.size(), "应截取 Top-2");

        assertTrue(ranker.rank(Arrays.asList(result(0, 5.0)), 0).isEmpty(), "topN=0 应返回空");
        assertTrue(ranker.rank(Arrays.asList(result(0, 5.0)), -1).isEmpty(), "topN<0 应返回空");
    }
}
