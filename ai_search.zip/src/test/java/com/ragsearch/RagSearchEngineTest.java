package com.ragsearch;

import com.ragsearch.model.SearchResult;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 端到端验收测试：基于真实 content.txt（5 个分片，ID 0-4 对应第 1-5 行），
 * 验证不同类型问题的搜索结果准确性——相关内容应排在首位（必然满足“前三位”要求）。
 *
 * <p>分片内容索引：
 * <ul>
 *   <li>分片 0（第 1 行）：大模型的定义</li>
 *   <li>分片 1（第 2 行）：大模型的特点（参数量大、训练数据大、计算资源大等）</li>
 *   <li>分片 2（第 3 行）：大模型的主要类别与应用领域</li>
 *   <li>分片 3（第 4 行）：中国算力中心机架规模数据</li>
 *   <li>分片 4（第 5 行）：中国生成式人工智能用户规模数据</li>
 * </ul>
 */
class RagSearchEngineTest {

    private final RagSearchEngine engine = new RagSearchEngine("content.txt");

    private int top1(String question) {
        List<SearchResult> results = engine.search(question, 3);
        assertTrue(!results.isEmpty(), "问题应能检索到相关内容: " + question);
        return results.get(0).getChunkId();
    }

    private List<Integer> top3(String question) {
        return engine.search(question, 3).stream()
                .map(SearchResult::getChunkId).collect(Collectors.toList());
    }

    @Test
    void 定义类问题_命中大模型定义行() {
        assertEquals(0, top1("什么是人工智能大模型？"));
        assertEquals(0, top1("人工智能大模型是指什么？"));
    }

    @Test
    void 特点类问题_命中大模型特点行() {
        assertEquals(1, top1("大模型有什么特点？"));
        assertEquals(1, top1("大模型的特点是什么？"));
    }

    @Test
    void 类别类问题_命中主要类别行() {
        assertEquals(2, top1("大模型的主要类别有哪些？"));
        assertEquals(2, top1("大模型分为哪些类别？"));
    }

    @Test
    void 数据类问题_命中算力规模行() {
        assertEquals(3, top1("中国算力中心机架总规模是多少？"));
    }

    @Test
    void 数据类问题_命中用户规模行() {
        assertEquals(4, top1("中国生成式人工智能用户规模是多少？"));
    }

    @Test
    void 应用类问题_命中应用领域行() {
        assertEquals(2, top1("大模型在哪些领域得到应用？"));
    }

    @Test
    void 相关内容均排在搜索结果前三位() {
        // 交付标准：常规问题输入下，相关内容排在搜索结果前三位（本实现达到第一位）
        assertTrue(top3("大模型的主要类别有哪些？").contains(2));
        assertTrue(top3("大模型有什么特点？").contains(1));
        assertTrue(top3("中国算力中心机架总规模是多少？").contains(3));
        assertTrue(top3("中国生成式人工智能用户规模是多少？").contains(4));
        assertTrue(top3("什么是人工智能大模型？").contains(0));
        // 换一种口语化说法同样命中
        assertTrue(top3("大模型可以应用在什么领域？").contains(2));
    }

    @Test
    void 搜索结果条数受TopN约束() {
        assertEquals(3, engine.search("大模型", 3).size(), "命中词元多于 3 个分片时应截取 Top-3");
        assertEquals(1, engine.search("大模型", 1).size());
        assertTrue(engine.search("大模型", 0).isEmpty());
    }

    @Test
    void 无关问题返回空结果() {
        assertTrue(engine.search("今天天气怎么样", 3).isEmpty(), "语料中无天气相关内容");
        assertTrue(engine.search("", 3).isEmpty(), "空问题应返回空结果");
    }

    @Test
    void 搜索结果具有确定性() {
        List<Double> first = engine.search("大模型的主要类别有哪些？", 3).stream()
                .map(SearchResult::getScore).collect(Collectors.toList());
        List<Double> second = engine.search("大模型的主要类别有哪些？", 3).stream()
                .map(SearchResult::getScore).collect(Collectors.toList());
        assertEquals(first, second, "相同问题两次搜索结果应完全一致");
    }

    @Test
    void 搜索结果附带行号与命中详情() {
        SearchResult first = engine.search("大模型的主要类别有哪些？", 3).get(0);
        assertEquals(3, first.getStartLine(), "应返回命中原文件行号");
        assertTrue(first.getScore() > 0);
        assertTrue(first.getSnippet(120).contains("大语言模型"), "摘要应来自命中分片原文");
    }
}
