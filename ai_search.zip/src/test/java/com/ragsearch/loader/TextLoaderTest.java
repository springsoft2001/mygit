package com.ragsearch.loader;

import com.ragsearch.model.Chunk;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** 文本加载器测试：按行分片、按段落分片、行号与内容完整性、异常路径 */
class TextLoaderTest {

    private static final String CONTENT = "content.txt";

    @Test
    void 按行分片_每行一个分片且行号正确() {
        List<Chunk> chunks = new TextLoader().load(CONTENT, TextLoader.ChunkMode.LINE);

        assertEquals(5, chunks.size(), "content.txt 共 5 个非空行");
        for (int i = 0; i < chunks.size(); i++) {
            assertEquals(i, chunks.get(i).getId(), "分片 ID 应从 0 连续递增");
            assertEquals(i + 1, chunks.get(i).getStartLine(), "起始行号应与文件行号一致");
            assertEquals(i + 1, chunks.get(i).getEndLine());
        }
        assertTrue(chunks.get(0).getRawText().contains("人工智能大模型"));
        assertTrue(chunks.get(0).getRawText().contains("是指"), "原文应保持未经删词的完整内容");
    }

    @Test
    void 按行分片_归一化文本已剔除停用词() {
        List<Chunk> chunks = new TextLoader().load(CONTENT, TextLoader.ChunkMode.LINE);
        // 第 1 行原文含“（简称“大模型”）是指由...”：归一化后括号引号折叠为空格、“是”“的”被剔除
        String matchText = chunks.get(0).getMatchText();
        assertTrue(matchText.startsWith("人工智能大模型"), "短语匹配文本应以正文起始");
        assertTrue(matchText.contains("简称"));
        assertTrue(!matchText.contains("的"), "虚词“的”应被剔除以保证查询/文档词元对齐");
    }

    @Test
    void 按段落分片_无空行时合并为单段() {
        List<Chunk> chunks = new TextLoader().load(CONTENT, TextLoader.ChunkMode.PARAGRAPH);

        // content.txt 无空行：按段落模式应合并为 1 个分片
        assertEquals(1, chunks.size());
        assertEquals(1, chunks.get(0).getStartLine());
        assertEquals(5, chunks.get(0).getEndLine());
        assertTrue(chunks.get(0).getRawText().contains("算力中心"));
        assertTrue(chunks.get(0).getRawText().contains("生成式人工智能"));
    }

    @Test
    void 分片已构建词频表() {
        List<Chunk> chunks = new TextLoader().load(CONTENT, TextLoader.ChunkMode.LINE);
        Chunk first = chunks.get(0);
        // “人工智能大模型”的二元词元“人工”在第 1 行出现 3 次（人工智能大模型/人工神经网络/人工智能模型）
        assertEquals(3, first.getTermFreq().getOrDefault("人工", 0));
        assertTrue(first.length() > 0, "文档长度（词元数）应为正");
    }

    @Test
    void 文件不存在时抛出明确异常() {
        assertThrows(IllegalArgumentException.class,
                () -> new TextLoader().load("no_such_file.txt"));
    }
}
