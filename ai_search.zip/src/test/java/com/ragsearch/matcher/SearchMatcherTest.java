package com.ragsearch.matcher;

import com.ragsearch.extractor.KeywordExtractor;
import com.ragsearch.index.InvertedIndex;
import com.ragsearch.model.Chunk;
import com.ragsearch.model.MatchResult;
import com.ragsearch.model.QueryAnalysis;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 搜索匹配器测试：以微型语料手工推导 BM25/短语/组合/覆盖率的精确数值，
 * 验证 TF-IDF 与各项得分的计算正确性。
 *
 * <p>语料：d1="apple banana"（词元 apple, banana，长度 2）；
 * d2="apple apple cherry"（词元 apple, apple, cherry，长度 3）。N=2，avgdl=2.5。
 * <p>查询 "apple banana"（两个西文整词关键词）：
 * <ul>
 *   <li>idf(apple)=ln(1+(2-2+0.5)/(2+0.5))=ln(1.2)=0.182322</li>
 *   <li>idf(banana)=ln(1+(2-1+0.5)/(1+0.5))=ln(2)=0.693147</li>
 *   <li>d1: norm=k1*(1-b+b*2/2.5)=1.02；apple tf=1 -&gt; 0.182322*2.2/2.02；
 *       banana tf=1 -&gt; 0.693147*2.2/2.02；BM25=0.953551</li>
 *   <li>d2: norm=1.38；apple tf=2 -&gt; 0.182322*4.4/3.38=0.237324；banana tf=0</li>
 *   <li>短语：d1 整串命中 apple(5 字符*0.5)+banana(6 字符*0.5)=5.5；d2 仅 apple=2.5</li>
 *   <li>组合：d1 中 apple 与 banana 相邻（gap=1&lt;=12） -&gt; 0.6*(5+6)=6.6；d2 未共现</li>
 *   <li>覆盖率：d1=2/2=1.0；d2=1/2=0.5</li>
 * </ul>
 */
class SearchMatcherTest {

    private final Chunk d1 = Chunk.of(0, 1, 1, "apple banana");
    private final Chunk d2 = Chunk.of(1, 2, 2, "apple apple cherry");
    private final InvertedIndex index = InvertedIndex.build(Arrays.asList(d1, d2));
    private final SearchMatcher matcher = new SearchMatcher(index);

    @Test
    void BM25与各项得分_精确数值校验() {
        QueryAnalysis query = new KeywordExtractor(index).extract("apple banana");
        MatchResult r1 = matcher.match(d1, query);
        MatchResult r2 = matcher.match(d2, query);

        assertEquals(0.953551, r1.getBm25Score(), 1e-4, "d1 的 BM25 得分");
        assertEquals(5.5, r1.getPhraseScore(), 1e-9, "d1 短语得分：apple(2.5)+banana(3.0) 整串命中");
        assertEquals(6.6, r1.getComboScore(), 1e-9, "d1 组合得分：两词临近共现");
        assertEquals(1.0, r1.getCoverage(), 1e-9, "d1 覆盖率 100%");
        assertEquals(0.953551 + 5.5 + 6.6 + 2.0, r1.getTotalScore(), 1e-4, "总分 = 各项之和");

        assertEquals(0.237324, r2.getBm25Score(), 1e-4, "d2 的 BM25 得分（仅 apple 命中且长度更长）");
        assertEquals(2.5, r2.getPhraseScore(), 1e-9, "d2 短语得分：仅 apple 命中");
        assertEquals(0.0, r2.getComboScore(), 1e-9, "d2 无组合共现");
        assertEquals(0.5, r2.getCoverage(), 1e-9, "d2 覆盖率 50%");

        assertTrue(r1.getTotalScore() > r2.getTotalScore(), "包含 banana 的分片应得分更高");
    }

    @Test
    void 命中关键词记录正确() {
        QueryAnalysis query = new KeywordExtractor(index).extract("apple banana");
        MatchResult r1 = matcher.match(d1, query);
        MatchResult r2 = matcher.match(d2, query);

        assertEquals(Arrays.asList("apple", "banana"), r1.getMatchedKeywords());
        assertEquals(Arrays.asList("apple"), r2.getMatchedKeywords());
    }

    @Test
    void IDF_平滑公式校验() {
        assertEquals(Math.log(1.2), index.idf("apple"), 1e-9, "df=N 的高频词 IDF");
        assertEquals(Math.log(2.0), index.idf("banana"), 1e-9, "df=1 的低频词 IDF");
        assertEquals(Math.log(1 + 2.5 / 0.5), index.idf("unseen"), 1e-9, "未见词元具有最大区分度");
    }

    @Test
    void 最长命中片段_降级匹配() {
        // 整串命中
        assertEquals("大模型", SearchMatcher.longestMatchedPiece("大模型", "人工智能大模型简称"));
        // 未整串命中时按最长片段降级：“大模型特点”无法整串命中，降级命中“大模型”
        assertEquals("大模型", SearchMatcher.longestMatchedPiece("大模型特点", "简称大模型 具大量特点"));
        // 完全未命中
        assertNull(SearchMatcher.longestMatchedPiece("苹果手机", "大模型简称"));
        // 过短关键词不参与短语匹配
        assertNull(SearchMatcher.longestMatchedPiece("的", "的的的"));
    }
}
