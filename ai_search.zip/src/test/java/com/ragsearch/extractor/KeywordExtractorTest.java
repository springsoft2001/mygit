package com.ragsearch.extractor;

import com.ragsearch.RagSearchEngine;
import com.ragsearch.model.Keyword;
import com.ragsearch.model.QueryAnalysis;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** 关键词提取器测试：中文关键词合并、停用词剔除、关键词组合构建、西文停用词 */
class KeywordExtractorTest {

    private final RagSearchEngine engine = new RagSearchEngine("content.txt");

    @Test
    void 中文问题_提取关键词并剔除停用词() {
        QueryAnalysis analysis = engine.analyze("大模型的主要类别有哪些？");

        List<Keyword> keywords = analysis.getKeywords();
        assertFalse(keywords.isEmpty(), "应能提取出关键词");

        String joined = keywords.stream().map(Keyword::getDisplay).collect(Collectors.joining());
        assertTrue(joined.contains("大模型"), "关键词应包含“大模型”");
        assertTrue(joined.contains("类别"), "关键词应包含“类别”");
        // 疑问词与虚词不应出现在关键词中
        for (Keyword kw : keywords) {
            assertFalse(kw.getDisplay().contains("哪些"), "疑问词“哪些”应被剔除");
            assertFalse(kw.getDisplay().contains("什么"), "疑问词“什么”应被剔除");
            assertFalse(kw.getDisplay().contains("的"), "虚词“的”应被剔除");
        }
    }

    @Test
    void 中文问题_重叠二元链合并为最大关键词() {
        // “的”被剔除后前后语义黏合：大模型|主要类别 合并为“大模型主要类别”
        QueryAnalysis analysis = engine.analyze("大模型的主要类别有哪些？");
        assertEquals(1, analysis.getKeywords().size(), "无标点分隔的连续词元链应合并为一个关键词");
        assertEquals("大模型主要类别", analysis.getKeywords().get(0).getDisplay());
        assertTrue(analysis.getKeywords().get(0).getTokens().contains("大模"), "关键词应携带原子词元用于匹配");
    }

    @Test
    void 标点分隔的问题_构建关键词组合() {
        // 顿号分词：得到两个关键词，并两两组合
        QueryAnalysis analysis = engine.analyze("大模型、应用领域");

        assertEquals(2, analysis.getKeywords().size());
        assertEquals("大模型", analysis.getKeywords().get(0).getDisplay());
        assertEquals("应用领域", analysis.getKeywords().get(1).getDisplay());
        assertEquals(1, analysis.getCombinations().size(), "相邻关键词应构建组合");
        assertEquals("大模型 + 应用领域", analysis.getCombinations().get(0).label());
    }

    @Test
    void 短语停用词切断词边界_虚词删除黏合语义() {
        // “有什么”中“什么”替换为空格切断边界，“有”直接删除
        QueryAnalysis analysis = engine.analyze("大模型有什么特点？");
        assertEquals(2, analysis.getKeywords().size());
        assertEquals("大模型", analysis.getKeywords().get(0).getDisplay());
        assertEquals("特点", analysis.getKeywords().get(1).getDisplay());
    }

    @Test
    void 西文停用词被剔除() {
        QueryAnalysis analysis = engine.analyze("What is the apple banana");
        assertEquals(2, analysis.getKeywords().size(), "what/is/the 应作为西文停用词剔除");
        assertEquals("apple", analysis.getKeywords().get(0).getDisplay());
        assertEquals("banana", analysis.getKeywords().get(1).getDisplay());
    }

    @Test
    void 全停用词问题_无关键词() {
        QueryAnalysis analysis = engine.analyze("你好吗");
        assertTrue(analysis.getKeywords().isEmpty(), "删除虚词后无有效关键词");
        assertTrue(analysis.getCombinations().isEmpty());
    }

    @Test
    void 关键词权重来自IDF() {
        QueryAnalysis analysis = engine.analyze("大模型、应用领域");
        // “应用领域”仅在文档中出现少量次数，IDF 应高于 ubiquitous 的“大模型”
        assertTrue(analysis.getKeywords().get(1).getWeight() > 0, "关键词权重应为 IDF 之和（正值）");
    }
}
