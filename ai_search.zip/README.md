# RAG 关键词搜索模块 · 开发说明文档

> 基于纯 Java 实现的 RAG（Retrieval-Augmented Generation）智能问答场景关键词搜索引擎，
> 提供**关键词提取 → 关键词组合构建 → TF-IDF/BM25 检索 → 相关性排序**的完整链路，
> 零外部依赖（仅 JDK + JUnit），支持生产级可维护性与运行效率。

---

## 目录

- [1. 项目概述](#1-项目概述)
- [2. 系统架构](#2-系统架构)
  - [2.1 整体流程](#21-整体流程)
  - [2.2 核心组件职责](#22-核心组件职责)
  - [2.3 数据流](#23-数据流)
- [3. 目录结构](#3-目录结构)
- [4. 环境要求与快速上手](#4-环境要求与快速上手)
  - [4.1 环境要求](#41-环境要求)
  - [4.2 构建与运行](#42-构建与运行)
  - [4.3 运行演示](#43-运行演示)
- [5. 核心算法详解](#5-核心算法详解)
  - [5.1 文本归一化与分词](#51-文本归一化与分词)
  - [5.2 停用词处理策略](#52-停用词处理策略)
  - [5.3 关键词合并与组合构建](#53-关键词合并与组合构建)
  - [5.4 TF-IDF / BM25 匹配打分](#54-tf-idf--bm25-匹配打分)
  - [5.5 短语匹配与临近共现加成](#55-短语匹配与临近共现加成)
  - [5.6 相关性排序](#56-相关性排序)
- [6. API 使用指南](#6-api-使用指南)
  - [6.1 引擎入口 RagSearchEngine](#61-引擎入口-ragsearchengine)
  - [6.2 结果模型](#62-结果模型)
  - [6.3 嵌入式集成示例](#63-嵌入式集成示例)
- [7. 配置参数与调优](#7-配置参数与调优)
- [8. 测试说明](#8-测试说明)
  - [8.1 单元测试覆盖](#81-单元测试覆盖)
  - [8.2 运行测试](#82-运行测试)
  - [8.3 验收标准](#83-验收标准)
- [9. 扩展点与二次开发](#9-扩展点与二次开发)
  - [9.1 接入更精确的中文分词器](#91-接入更精确的中文分词器)
  - [9.2 多文档源加载](#92-多文档源加载)
  - [9.3 增量索引](#93-增量索引)
  - [9.4 同义词扩展](#94-同义词扩展)
- [10. 常见问题 FAQ](#10-常见问题-faq)

---

## 1. 项目概述

| 维度 | 说明 |
|------|------|
| **定位** | RAG 智能问答系统的检索层核心，负责从本地文本中按关键词相关性快速定位答案片段 |
| **语言 & 版本** | Java 11+（本工程在 JDK 21 LTS 下验证通过） |
| **构建工具** | Apache Maven 3.6+ |
| **外部依赖** | 零（仅测试期依赖 JUnit Jupiter 5.10） |
| **核心算法** | Okapi BM25（TF-IDF 的业界演进版） + 短语匹配 + 临近共现加成 + 覆盖率归一化 |
| **数据源** | 工程根目录 `content.txt`（UTF-8，按行或按段落分片） |

**设计原则：**

1. **纯 Java 零依赖** —— 便于嵌入任意应用、避免版本冲突；
2. **可解释性优先** —— 每项得分（BM25 / 短语 / 组合 / 覆盖率）独立可见，便于调试与调优；
3. **生产可用标准** —— BM25 参数取 Lucene/ES 同款默认值、中文分词采用 CJK Bigram 业界通行方案；
4. **确定性输出** —— 同分按 chunkId 稳定排序，相同问题两次结果完全一致。

---

## 2. 系统架构

### 2.1 整体流程

```
用户问题 ──→ [Tokenize + 归一化 + 停用词剔除]
            ──→ [关键词提取器] ──→ 关键词 + 关键词组合
                                          │
content.txt ──→ [文本加载器] ──→ Chunk 分片  │
                  │                       │
                  └──→ [倒排索引构建]       │
                        (df / idf / avgdl) │
                                          ▼
                                   [搜索匹配器]
                                  (BM25 + 短语 + 组合 + 覆盖率)
                                          │
                                          ▼
                                   [结果排序器]
                                  (降序 + 稳定 + Top-N)
                                          │
                                          ▼
                                   List<SearchResult>
```

### 2.2 核心组件职责

| 组件 | 全限定名 | 职责 |
|------|---------|------|
| **文本加载器** | `com.ragsearch.loader.TextLoader` | 读取 content.txt，支持按行 / 按段落两种分片模式；构建 Chunk 对象（含归一化文本、词频表） |
| **关键词提取器** | `com.ragsearch.extractor.KeywordExtractor` | 对问题完成归一化、停用词剔除、分词、**位置连续词元链合并为最大关键词**、相邻关键词两两组合 |
| **搜索匹配器** | `com.ragsearch.matcher.SearchMatcher` | 基于倒排索引，对每个 Chunk 计算 **BM25 得分 + 短语得分 + 组合得分 + 覆盖率** |
| **结果排序器** | `com.ragsearch.ranker.ResultRanker` | 按总分降序、同分按 chunkId 升序稳定排序；过滤零分；截取 Top-N |
| **倒排索引** | `com.ragsearch.index.InvertedIndex` | 一次性统计 df、idf、avgdl；提供 BM25 所需 IDF 查询 |
| **文本处理** | `com.ragsearch.text.{Tokenizer, Stopwords}` | NFKC 归一化 + 小写 + 中文重叠二元分词；疑问词/虚词剔除 |
| **引擎入口** | `com.ragsearch.RagSearchEngine` | 四大组件的编排者，提供 `analyze()` 和 `search()` |

### 2.3 数据流

```
content.txt (UTF-8)
    │
    ├── TextLoader.load() ──→ List<Chunk>
    │       │                       │
    │       │  每个 Chunk 构造时：      │
    │       │   1. normalize(raw)    │
    │       │   2. stripStopwords() │
    │       │   3. tokenize()       │
    │       │   4. 构建 termFreq    │
    │       │                       │
    │       └──→ InvertedIndex.build(List<Chunk>)
    │                   ├── docFreq(term)  // 文档频率
    │                   ├── idf(term)      // 平滑 IDF
    │                   └── avgDocLen     // 平均文档长度
    │
    └── 用户问题 ──→ KeywordExtractor.extract(question)
                          ├── QueryAnalysis.keywords      // 最大关键词链
                          └── QueryAnalysis.combinations  // 相邻关键词对

    RagSearchEngine.search(question, topN):
        for each Chunk: SearchMatcher.match(chunk, query)
            ├── BM25(termFreq, idf, avgdl)
            ├── PhraseScore(longestMatchedPiece)
            ├── ComboScore(slop 临近共现)
            └── Coverage(hitTerms / queryTerms)
        └── ResultRanker.rank(matches, topN)
```

---

## 3. 目录结构

```
rag-keyword-search/
├── pom.xml                                     # Maven 构建文件
├── content.txt                                 # 检索数据源（工程根目录，UTF-8）
├── README.md                                   # 本文档
└── src/
    ├── main/java/com/ragsearch/
    │   ├── Main.java                           # 命令行入口（演示用）
    │   ├── RagSearchEngine.java                # 引擎编排者（门面类）
    │   ├── loader/
    │   │   └── TextLoader.java                 # 【核心组件一】文本加载器 + 分片
    │   ├── extractor/
    │   │   └── KeywordExtractor.java           # 【核心组件二】关键词提取 + 组合构建
    │   ├── matcher/
    │   │   └── SearchMatcher.java              # 【核心组件三】BM25/短语/组合匹配
    │   ├── ranker/
    │   │   └── ResultRanker.java               # 【核心组件四】结果排序
    │   ├── index/
    │   │   └── InvertedIndex.java              # 倒排索引 + IDF 统计
    │   ├── text/
    │   │   ├── Tokenizer.java                  # NFKC 归一化 + 中文二元分词
    │   │   └── Stopwords.java                  # 停用词（疑问词 + 虚词 + 西文停用词）
    │   └── model/
    │       ├── Chunk.java                      # 文本分片（含词频、归一化文本）
    │       ├── Keyword.java                    # 关键词（最大合并链 + 权重）
    │       ├── KeywordCombination.java         # 关键词组合（相邻关键词对）
    │       ├── QueryAnalysis.java              # 查询分析结果
    │       ├── MatchResult.java                # 单个 Chunk 的匹配详情（各分项得分）
    │       └── SearchResult.java               # 最终排序结果（含名次、行号、摘要）
    └── test/java/com/ragsearch/
        ├── RagSearchEngineTest.java            # 端到端验收测试（11 cases）
        ├── SearchMatcherTest.java              # BM25 手工数值校验 + IDF 边界
        ├── KeywordExtractorTest.java           # 关键词合并、停用词、组合构建
        ├── TextLoaderTest.java                 # 分片行号、词频、归一化
        └── ResultRankerTest.java               # 降序、稳定、TopN、零分过滤
```

---

## 4. 环境要求与快速上手

### 4.1 环境要求

| 依赖 | 版本 | 说明 |
|------|------|------|
| JDK | 11 及以上 | 已在 JDK 21 LTS 验证通过 |
| Maven | 3.6 及以上 | 仅用于构建与运行测试 |

> **零运行时依赖**：打包为可独立运行的 JAR 或嵌入其他工程均无需额外引入。

### 4.2 构建与运行

```bash
# 1. 编译
mvn compile

# 2. 运行全部单元测试
mvn test
# 预期：Tests run: 31, Failures: 0, Errors: 0, Skipped: 0

# 3. 运行 Main（内置 4 个演示问题）
java -cp target/classes com.ragsearch.Main

# 4. 自定义问题
java -cp target/classes com.ragsearch.Main "大模型的主要类别有哪些？"
```

### 4.3 运行演示

**问题：** `大模型的主要类别有哪些？`

```
[问题] 大模型的主要类别有哪些？
  提取关键词: 大模型主要类别(权重 5.72)
  关键词组合: 无

  搜索结果 Top 3:
    #1 得分=15.44 (BM25=6.44, 短语=7.00, 组合=0.00) 覆盖率=100% 命中=[大模型主要类别] 来源=第3行
        内容: 人工智能大模型的主要类别包括：大语言模型、视觉大模型、多模态大模型以及基础科学大模型等...
    #2 得分=3.97 (BM25=0.31, 短语=3.00, 组合=0.00) 覆盖率=33% 命中=[大模型] 来源=第1行
        内容: 人工智能大模型（简称"大模型"）是指由人工神经网络构建的一类具有大量参数的人工智能模型。
    #3 得分=3.94 (BM25=0.27, 短语=3.00, 组合=0.00) 覆盖率=33% 命中=[大模型] 来源=第5行
        内容: 截至2025年6月，中国生成式人工智能用户规模达5.15亿人...
```

**问题：** `中国生成式人工智能用户规模是多少？`

```
#1 得分=25.06 ... 覆盖率=100% 来源=第5行
    内容: 截至2025年6月，中国生成式人工智能用户规模达5.15亿人...
```

---

## 5. 核心算法详解

### 5.1 文本归一化与分词

**归一化（`Tokenizer.normalize`）**

1. `Normalizer.Form.NFKC`：全角字母/数字/标点折叠为半角（如 `（）` → `()`，`１` → `1`，`：` → `:`）；
2. 统一小写；
3. 中文 / 字母 / 数字之外的所有字符（标点、空白、符号）折叠为单个空格，保留词边界。

**分词（`Tokenizer.tokenize`）**

- **中文连续段**：采用**重叠二元切分**（CJK Bigram，Lucene `CJKAnalyzer` / ES `ik_smart` 等主流方案的基础）。例如 `"大模型"` → `[大模, 模型]`，兼顾召回与实现简单；
- **字母/数字连续段**：作为整词，如 `"tfidf2025"` → `[tfidf2025]`；
- **单字中文**：保留为单字 Token（避免信息丢失）。

> CJK Bigram 的优势：**无需外部字典**、**无歧义切分**、**OOV（未登录词）天然可召回**，代价是索引体积略大，但在 RAG 场景下可接受。

### 5.2 停用词处理策略

**核心矛盾：** 中文虚词（"的" "了" "是"）如果简单删除会破坏词边界，而保留则会污染索引。本模块采用**两层策略**：

| 类型 | 处理方式 | 示例 |
|------|---------|------|
| **短语级疑问词**（"什么" "哪些" "怎么" "请问"） | 替换为**空格**（切断边界） | `"什么是大模型"` → `"  大模型"` |
| **中文虚词单字**（"的" "了" "是" "有" "在" "和"...） | **直接删除**（不引入空格，使前后语义黏合） | `"大模型的类别"` → `"大模型类别"` |
| **西文停用词**（`the`, `is`, `what`, `which`...） | 在关键词构建阶段按**整词**过滤 | `"What is the Apple"` → 仅保留 `Apple` |

**关键设计：** 查询侧和文档侧应用同一套停用词处理规则，保证两侧词元对齐。

### 5.3 关键词合并与组合构建

**最大关键词合并（`KeywordExtractor`）**

重叠二元 Token 的位置特征：相邻 Token 的 `start` 呈 `i, i+1, i+2, ...` 连续递增。

```
原问题: "大模型的主要类别"
  ├─ 归一化: "大模型的主要类别"
  ├─ 停用词剔除: "大模型主要类别"  ← "的" 被直接删除，前后黏合
  ├─ Tokenize: [大模(0), 模型(1), 型主(2), 主要(3), 要类(4), 类别(5)]
  └─ 位置连续链合并 → 关键词 "大模型主要类别"（6 个二元连成一串）
```

**关键词权重 = Σ idf(token)**，衡量关键词的区分度（罕见词元权重高，通用词元权重低）。

**关键词组合构建**

标点、疑问词切断的场景下，相邻关键词两两配对形成 AND 组合：

```
问题: "大模型、应用领域"
  → 关键词: ["大模型", "应用领域"]
  → 组合:   [大模型 + 应用领域]
```

组合用于匹配阶段的**临近共现加成**（两关键词在分片内的字符窗口内共现时加分）。

### 5.4 TF-IDF / BM25 匹配打分

#### TF-IDF 逆文档频率（`InvertedIndex.idf`）

采用 BM25 平滑公式（Lucene / Okapi 标准），**恒为正值**、避免高频词负权重的业界通病：

```
idf(t) = ln(1 + (N - df(t) + 0.5) / (df(t) + 0.5))

N        = chunk 总数
df(t)    = 包含词元 t 的 chunk 数
```

| df 值 | idf 物理意义 |
|-------|-------------|
| df = N（高频） | ln(1 + 0.5/(N+0.5)) ≈ 0，权重极低 |
| df = 1（罕见） | ln(1 + (N-0.5)/1.5)，区分度高 |
| df = 0（未见） | ln(1 + (N+0.5)/0.5)，最大区分度 |

#### BM25 打分（`SearchMatcher`）

Okapi BM25 是 TF-IDF 的业界演进版，**额外引入词频饱和（k1）和文档长度归一化（b）**：

```
score_bm25(d, q) = Σ_{t ∈ q} idf(t) · TF(t,d) · (k1 + 1) / (TF(t,d) + k1 · (1 - b + b · |d| / avgdl))

TF(t,d)    = 词元 t 在文档 d 中的出现次数
|d|        = 文档 d 的长度（词元数）
avgdl      = 语料平均文档长度
k1 = 1.2   = 词频饱和参数（默认值，高频词边际收益递减）
b  = 0.75  = 长度归一化参数（默认值，抑制长文档天然优势）
```

**单元测试验证示例**（微型语料手工推导）：

```
d1="apple banana" (TF: apple=1, banana=1, |d|=2)
d2="apple apple cherry" (TF: apple=2, cherry=1, |d|=3)
N=2, avgdl=2.5

idf(apple) = ln(1 + (2-2+0.5)/(2+0.5)) = ln(1.2) = 0.1823
idf(banana) = ln(1 + (2-1+0.5)/(1+0.5)) = ln(2.0) = 0.6931

BM25(d1, "apple banana") = 0.1823·1·2.2/(1+1.2·(1-0.75+0.75·2/2.5))
                        + 0.6931·1·2.2/(1+1.2·(1-0.75+0.75·2/2.5))
                        = 0.9535  ← 精确数值，单元测试断言到 1e-4
```

### 5.5 短语匹配与临近共现加成

短语匹配弥补 BM25 仅关注原子词元、忽略词序的不足（BM25 中 `"苹果手机"` 和 `"手机苹果"` 得分相同，但实际相关性天差地别）。

#### 短语得分（`SearchMatcher.longestMatchedPiece`）

- **优先整串命中**：关键词完整出现在分片归一化文本中 → 最高加分
- **降级策略**：从长到短滑动窗口（最低 2 字符）寻找最长可命中片段
- **计分规则**：中文 1.0/字符，西文 0.5/字符（西文近似按音节折算）

```
关键词 "大模型" → 分片文本含 "大模型"
  → 整串命中 → 3 × 1.0 = 3.0

关键词 "大模型特点" → 分片文本含 "大模型" 但不含 "特点"
  → 降级命中 "大模型" → 3 × 1.0 = 3.0
```

#### 组合临近共现加成（slop 匹配）

参考 Elasticsearch `match_phrase` 查询的 slop 思想：关键词组合的两端关键词在分片内限定字符窗口（slop=12）内共现时，给予额外加成。

```
组合 "大模型 + 应用领域"  在分片中出现：
  gap = |pos("应用领域") - pos("大模型") - len("大模型")|
  如果 gap ≤ 12: comboScore += 0.6 × (len(piece1) + len(piece2))
```

### 5.6 相关性排序

**总分公式（`SearchMatcher`）**

```
total = BM25Score + PhraseScore + ComboScore + COVERAGE_WEIGHT × coverage

coverage = 命中的查询词元数 / 查询总词元数
COVERAGE_WEIGHT = 2.0
```

覆盖率项保证：**匹配率高**的分片优先于**局部得分高但覆盖面窄**的分片。

**排序规则（`ResultRanker`）**

1. 按 `totalScore` 降序；
2. 同分按 `chunkId` 升序稳定排序 → 结果**完全确定性**；
3. 过滤 `totalScore ≤ ε`（零分，无任何命中）的分片；
4. 截取 Top-N。

---

## 6. API 使用指南

### 6.1 引擎入口 `RagSearchEngine`

```java
public class RagSearchEngine {
    // 构造：默认按行分片
    public RagSearchEngine(String contentPath);

    // 构造：指定分片模式（LINE / PARAGRAPH）
    public RagSearchEngine(String contentPath, TextLoader.ChunkMode mode);

    // 仅做查询分析（关键词 + 组合），不检索
    public QueryAnalysis analyze(String question);

    // 完整搜索：返回 Top-N 结果
    public List<SearchResult> search(String question, int topN);

    // 分片数量（调试用）
    public int chunkCount();
}
```

### 6.2 结果模型

| 类 | 关键字段 | 说明 |
|----|---------|------|
| `QueryAnalysis` | `keywords`, `combinations` | 提取的关键词（带权重）和相邻关键词对 |
| `SearchResult` | `rank`, `score`, `startLine`, `endLine`, `bm25Score`, `phraseScore`, `comboScore`, `coverage`, `matchedKeywords`, `rawText`, `snippet(maxChars)` | 完整的结果定位与解释信息 |

### 6.3 嵌入式集成示例

```java
import com.ragsearch.RagSearchEngine;
import com.ragsearch.model.SearchResult;

public class RagDemo {
    public static void main(String[] args) {
        // 引擎初始化（仅加载一次）
        RagSearchEngine engine = new RagSearchEngine("content.txt");

        // 问题分析（可选，用于日志/调试）
        var analysis = engine.analyze("大模型的主要类别有哪些？");
        System.out.println("关键词: " + analysis.getKeywords());
        System.out.println("组合: " + analysis.getCombinations());

        // 检索 Top-3
        List<SearchResult> results = engine.search("大模型的主要类别有哪些？", 3);

        for (SearchResult r : results) {
            System.out.printf("#%d [得分=%.2f 覆盖率=%.0f%% 第%d行]%n",
                    r.getRank(), r.getScore(), r.getCoverage() * 100, r.getStartLine());
            System.out.println("  " + r.getSnippet(150));
        }
    }
}
```

**输出**

```
#1 [得分=15.44 覆盖率=100% 第3行]
  人工智能大模型的主要类别包括：大语言模型、视觉大模型、多模态大模型以及基础科学大模型等...
#2 [得分=3.97 覆盖率=33% 第1行]
  人工智能大模型（简称"大模型"）是指由人工神经网络构建的一类具有大量参数的人工智能模型。
#3 [得分=3.94 覆盖率=33% 第5行]
  截至2025年6月，中国生成式人工智能用户规模达5.15亿人...
```

---

## 7. 配置参数与调优

所有参数集中定义在 `SearchMatcher.java` 类顶部，便于统一调整：

| 参数 | 默认值 | 位置 | 含义 | 调优建议 |
|------|--------|------|------|---------|
| `K1` | 1.2 | BM25 | 词频饱和参数 | 小语料库 1.0~1.4；高频词抑制强弱 |
| `B` | 0.75 | BM25 | 文档长度归一化 | 0 不归一化；1 完全归一化；业界 0.75 |
| `CJK_CHAR_WEIGHT` | 1.0 | 短语得分 | 中文每字符权重 | 短语匹配偏好度，调高则整串匹配更重要 |
| `LATIN_CHAR_WEIGHT` | 0.5 | 短语得分 | 西文每字符权重 | 西文近似按音节折算 |
| `COMBO_WEIGHT` | 0.6 | 组合得分 | 临近共现加成系数 | 调高 → 组合匹配更敏感 |
| `COMBO_SLOP` | 12 | 组合得分 | 临近窗口（字符数） | 中文 8~15，西文 15~25 |
| `COVERAGE_WEIGHT` | 2.0 | 覆盖率 | 覆盖率加成系数 | 调高 → 多关键词命中更重要 |

**调优场景举例：**

- 短问题（2~3 词）：`COMBO_SLOP` 可调小至 8；
- 长问题（复合句）：`COMBO_SLOP` 调大至 20，`COVERAGE_WEIGHT` 提高至 3.0；
- 专业术语密集的语料（术语往往固定词组）：`CJK_CHAR_WEIGHT` 调高至 1.5。

---

## 8. 测试说明

### 8.1 单元测试覆盖

| 测试类 | 用例数 | 覆盖内容 |
|--------|--------|---------|
| `RagSearchEngineTest` | 11 | **端到端验收**：定义/特点/类别/算力规模/用户规模/应用领域共 6 类问题的 Top1 准确性 + 前三位 + 边界（TopN、无关问题、空问题、确定性） |
| `SearchMatcherTest` | 4 | **BM25 精确数值校验**（微型语料，断言到 1e-4）+ IDF 边界（高频/低频/未见词）+ 最长命中片段降级匹配 |
| `KeywordExtractorTest` | 7 | 停用词剔除、重叠二元链合并为最大关键词、标点分隔构建组合、西文停用词、全停用词问题 |
| `TextLoaderTest` | 5 | 按行分片行号、归一化文本、按段落分片、词频构建、异常路径 |
| `ResultRankerTest` | 4 | 降序、同分稳定、零分过滤、TopN 截断 |
| **合计** | **31** | |

### 8.2 运行测试

```bash
# 运行全部
mvn test

# 运行单个测试类
mvn -Dtest=SearchMatcherTest test

# 运行单个测试方法
mvn -Dtest=SearchMatcherTest#BM25与各项得分_精确数值校验 test
```

### 8.3 验收标准

> 需求原文：**"确保在常规问题输入下，相关内容能够排在搜索结果的前三位"**

| 指标 | 标准 | 本项目实测 |
|------|------|-----------|
| 定义类问题（"什么是大模型"） | 相关行在前三位 | ✅ Top1 命中第 1 行 |
| 特点类问题（"大模型有什么特点"） | 相关行在前三位 | ✅ Top1 命中第 2 行 |
| 类别类问题（"大模型有哪些类别"） | 相关行在前三位 | ✅ Top1 命中第 3 行 |
| 算力数据类问题 | 相关行在前三位 | ✅ Top1 命中第 4 行 |
| 用户规模数据类问题 | 相关行在前三位 | ✅ Top1 命中第 5 行 |
| 应用领域类问题 | 相关行在前三位 | ✅ Top1 命中第 3 行 |
| **所有类型问题** | **相关行前三位** | **✅ 全部 Top1** |
| BM25 数值准确性 | 精确到 1e-4 | ✅ 手工数学推导验证 |
| 结果确定性 | 同问题两次输出一致 | ✅ 测试用例验证 |

---

## 9. 扩展点与二次开发

### 9.1 接入更精确的中文分词器

CJK Bigram 方案简单但会产生过粗的词元（"人工智能" → "人工" "工智" "智能"）。如需更精确：

```java
// Step 1: 引入依赖（以 JSegment 为例）
// pom.xml
// <dependency>
//   <groupId>com.zouqi</groupId><artifactId>JSegment</artifactId><version>2.0.3</version>
// </dependency>

// Step 2: 实现 Tokenizer 接口
public class SegmentTokenizer extends Tokenizer {
    public static List<Token> tokenize(String text) {
        List<Token> tokens = new ArrayList<>();
        List<String> words = JSegment.segment(text);
        int pos = 0;
        for (String word : words) {
            tokens.add(new Token(word, pos, pos + word.length(), false));
            pos += word.length();
        }
        return tokens;
    }
}
```

### 9.2 多文档源加载

```java
public class MultiFileLoader extends TextLoader {
    public List<Chunk> loadDirectory(Path dir, ChunkMode mode) {
        List<Chunk> all = new ArrayList<>();
        int baseId = 0;
        for (Path file : Files.list(dir).toList()) {
            List<Chunk> chunks = super.load(file.toString(), mode);
            for (Chunk c : chunks) {
                all.add(Chunk.of(baseId + c.getId(), c.getStartLine(), c.getEndLine(), c.getRawText()));
            }
            baseId += chunks.size();
        }
        return all;
    }
}
```

### 9.3 增量索引

当前 `InvertedIndex` 是一次性构建。若需支持动态添加分片：

```java
public void addChunk(Chunk chunk) {
    // 更新 df
    for (String term : chunk.getTermFreq().keySet()) {
        docFreq.merge(term, 1, Integer::sum);
    }
    // 更新 avgdl
    int newSize = chunks.size() + 1;
    double totalLen = avgDocLen * chunks.size() + chunk.length();
    // ... 重新计算
    chunks.add(chunk);
}
```

### 9.4 同义词扩展

```java
public class SynonymExpander {
    private static final Map<String, String[]> SYNONYMS = Map.of(
            "大模型", new String[]{"人工智能大模型", "LLM"},
            "应用", new String[]{"使用", "落地", "实践"}
    );

    public List<String> expand(String term) {
        List<String> result = new ArrayList<>();
        result.add(term);
        if (SYNONYMS.containsKey(term)) {
            result.addAll(Arrays.asList(SYNONYMS.get(term)));
        }
        return result;
    }
}
```

在 `KeywordExtractor` 中对每个关键词调用 `expand()`，将同义词作为额外查询词元加入。

---

## 10. 常见问题 FAQ

### Q1：为什么不用外部中文分词库（如 Jieba / HanLP）？

**A：** 零依赖是本模块的核心设计原则之一。CJK Bigram 方案在 RAG 问答场景下召回率足够，且避免了字典维护、版本冲突等工程问题。如需更高精度，可参考 [第 9.1 节](#91-接入更精确的中文分词器) 接入。

### Q2：TF-IDF 和 BM25 什么关系？

**A：** TF-IDF 是基础思想：词频越高越重要、文档频率越高越不重要。BM25 是 TF-IDF 的**业界演进版**，额外引入了 **k1 词频饱和**（高频词边际收益递减，避免某个词出现 100 次比出现 10 次重要 10 倍的不合理情况）和 **b 文档长度归一化**（避免长文档天然占优）。Lucene、Elasticsearch 的默认打分就是 BM25。

### Q3：为什么停用词是"替换为空格" vs "直接删除"两种策略？

**A：** 这是本模块的关键设计。假设问题是 `"大模型的类别"`，如果简单删除 `"的"` 后保留空格，归一化文本会变成 `"大模型 类别"`，分词器会产生 `"型类"` 这个词元；但如果**直接删除不引入空格**，文本变成 `"大模型类别"`，分词器产生 `"模型"` `"类别"` 这些更有意义的词元。疑问词（"什么" "哪些"）由于是多字词组，用空格替换更合适以切断边界。

### Q4：中文重叠二元会不会导致索引体积过大？

**A：** 会有一定膨胀。中文 N 字词语料二元词元数为 N-1 个，相比精确分词约多 30%~50%。但在 RAG 问答场景下，content.txt 通常是 KB 级（本项目 1.9KB），索引构建 O(毫秒)；即使扩展到 MB 级也完全够用。

### Q5：搜索结果是确定性的吗？

**A：** 完全确定。同分按 chunkId 升序稳定排序，相同问题两次调用 `search()` 返回的 `SearchResult` 列表逐元素 equals。单元测试 `搜索结果具有确定性()` 专门验证此点。

### Q6：如果 content.txt 很大怎么办？

**A：** 当前 `InvertedIndex` 是全量一次性加载到内存，对 MB 级语料无压力。GB 级语料可参考 [第 9.3 节](#93-增量索引) 做增量加载，或参考外部搜索引擎（ES/Solr）的 segment 索引设计。

### Q7：如何调整 Top-N 返回数量？

**A：** `engine.search(question, n)` 第二个参数即为 N。传 0 或负数返回空列表（已在单元测试中验证）。

### Q8：Windows 终端运行中文乱码怎么办？

**A：** 这是 PowerShell 编码问题（GBK vs UTF-8）。两种解决方式：

```powershell
# 方式一：设置输出编码
[Console]::OutputEncoding = [Text.Encoding]::UTF8
java -cp target/classes com.ragsearch.Main

# 方式二：使用 cmd.exe
cmd /c "chcp 65001 && java -cp target\classes com.ragsearch.Main"
```

源码文件本身已是 UTF-8 无 BOM，`content.txt` 也是 UTF-8，Maven surefire 运行测试不受影响（JUnit 报告用 UTF-8）。
